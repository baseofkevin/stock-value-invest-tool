# 数据源路由（Sources）

- 日期：2026-11-14（**§2/§3/§6/§7/§9/§11/§12 于 15:50 按第 3 步实测结果修订**）
- 状态：**§1–§11 已定；§3 矩阵的 `kline` 行、§9 注册表已落地**（`stock_data_fetch/sources/` 754 行）。`finance`/`valuation` 的源仍待第 5 步接
- 上游依据：`讨论纪要-共享数据层.md` §18（限频实测）、**§22（第 3 步：tdx 401 / 东财可用 / 掐连接）**、`CONTRACT-stock_data_fetch.md` §7（节流）、`SCHEMA-共享库.md` §4.4（fp）
- 读者：写 `stock_data_fetch/sources/` 的人、以后想加源的人

> 这份文件回答一个问题：**六个以上的源，怎么组织才不乱。**
> 不是"选哪个源"，是"怎么让源可插拔、可校验、可切换，且切换不污染数据"。

---

## 1. 先说结论：不是三选一，是分层

现在的源已经不止三个：

| 类 | 源 | 性质 |
|---|---|---|
| 官方 MCP | 腾讯自选股（westock）、通达信（tdx） | 有连接器、有令牌、限频按配额 |
| 直连 HTTP | 东方财富 datacenter（quality 里已有的 `providers/eastmoney.py`） | 无令牌、每请求 400ms 节流 |
| 开源库 | baostock、akshare、efinance、… | 无令牌、可选依赖、接口会漂 |

如果按"源"这个粒度去写死优先级，加到第 6 个源就会变成一堆 `if src ==`。所以先分层，**层与层之间只通过一个契约通信**：

```
第 1 层  上游（数据从哪来）  腾讯自选股 / 东方财富 / 通达信 / baostock 自有库 / 交易所·新浪
第 2 层  传输（怎么拿）      MCP 客户端 / 直连 HTTP / 开源库
第 3 层  适配器（怎么变成行） stock_data_fetch.sources.<name>.fetch(domain, codes, need) -> Got
第 4 层  路由（该用谁）      router.pick(domain) -> [(source, priority), ...]
```

**第 1 层与第 2 层的分离是最重要的一条**：

- `efinance` 的上游是**东方财富**，不是新源。它只是"另一条到东财的传输"。
- `akshare` 的 `stock_zh_a_hist` 上游也是**东财**，`stock_zh_a_daily` 上游是**新浪**，`stock_a_indicator_lg` 上游是**乐咕**——一个库里混着多个上游，不能整体当"一个源"看待。
- `baostock` 是**自有库**（数据来自交易所授权整理），是真正独立的上游。

这条分离直接决定了下一节的铁律 2：**同上游的两个传输互相校验，等于自己校验自己。**

---

## 2. 源清单

| 源 | 上游 | 传输 | 依赖 | 配额/节流 | 批量 | 稳定度 |
|---|---|---|---|---|---|---|
| `westock` | 腾讯自选股 | MCP（令牌） | 无（标准库 JSON-RPC） | **按返回行数**，实测约 15k 行/分钟 | ≤150 只/次 | 高（官方连接器） |
| `tdx` | 通达信 | MCP（**OAuth 令牌**） | 无 | 未知，最小间隔定 300ms（未实测） | 1 只 | 高（官方连接器）但**独立进程 401** ⁷ |
| `eastmoney` | 东方财富 | 直连 HTTP `datacenter` / `push2his` | 无（标准库） | **按行数**，突发会掐连接（§6） | 单只（一次给全历史） | 中（有限频，但不封禁） |
| `baostock` | baostock 自有库 | 开源库（socket） | `baostock`（纯标准库+socket，无 pandas） | 未知，串行 | 1 只 | 中（更新频率需实测） |
| `akshare` | 东财/新浪/乐咕… | 开源库 | `akshare` + `pandas` | 无显式，靠上游 | 视函数 | **低**（函数名随版本改） |
| `efinance` | 东方财富 | 开源库 | `efinance` + `pandas` | 无显式，靠东财 | 单只 | 中 |

「稳定度」是主观评级，依据是：接口是否随版本改名、是否依赖 pandas、是否有官方维护承诺。**这三条决定了它们在路由里的位置（见 §5）。**

> **2026-11-14 实测：baostock 在本机不可用。** 装得上（`baostock 0.9.4` + `pandas 3.1.1`，装在隔离 venv），但 `bs.login()` 直接返回
> `10001011 黑名单用户，请与管理员联系` —— 是 IP/网络侧被拒，不是代码问题。
> 后果：**§3 里靠 baostock 做"因子金标准"与"估值独立校验"的两条，目前无法落地**，复权仍是 tdx 单基准、估值仍无独立源。
> 同一时间东财 `RPT_VALUEANALYSIS_DET` 实测可用（茅台 2150 个交易日，PE_TTM/PB_MRQ/PS_TTM 齐全），所以 `valuation` 主源没问题。
> baostock 保留在注册表里、标记为 `AVAILABLE=False`，换到别的网络再试。

> **2026-11-14 实测：`kline` 的原定主源 tdx 在独立进程里用不了。** 宿主里的 tdx 连接器一切正常，但 `stock_data_fetch` 作为 CLI 进程去 `POST` MCP 端点，`initialize` 就被
> `401 Missing Bearer authorization` 挡住——令牌在宿主进程内存里，落不到磁盘。同时实测东财 `push2his` `fqt=0` **无鉴权**、一次给全历史、
> 且 raw **与 tdx 逐点同值**（脚注 ⁶ 有三组对照）。于是 `kline` 主源改为 **eastmoney**，tdx 降为备源并由令牌探测自动启用。
> 这次换源没有动 `fp`、没有作废旧数据——依据就是 §4.1 表里 `kline` raw 那一行"混得起"。

---

## 3. 域 × 源 矩阵

标记：**主** = 首选；备 = 主源不可用时整段切换；验 = 只用于交叉校验，不写库；— = 不可用或不该用。

| 域 | westock（腾讯） | eastmoney（东财） | tdx（通达信） | baostock | akshare | efinance |
|---|---|---|---|---|---|---|
| `kline` 原材料 | — ¹ | **主**（`fqt=0`）⁶ | 主→**备**（要令牌）⁷ | 备（`adjustflag=3`） | 备 | 备 |
| 复权因子校验 | — | — | 基准（qfq 价格） | **验** ² | — | — |
| `finance` 三表 | **主** | 备（`RPT_*`） | — | 验 ³ | 备 | 备 |
| `dividend` | **主** | 备 | 验（F10） | 验 | 备 | — |
| `valuation` 周频 | — | **主**（`RPT_VALUEANALYSIS_DET`） | — | 验 ⁴ | 备（乐咕） | 备 |
| `quote` 快照 | **主**（批量） | 备 | 备（单只） | — ⁵ | 备 | 备 |
| `profile` | **主** | 备 | 备（F10 `gsgk`） | 备 | 备 | 备 |
| 交易日历 | **主**（`data_trade_calendar`） | 备 | — | **验**（`query_trade_dates`） | 备 | — |

脚注（每一条都是"为什么不能拿它当主源"）：

1. westock 的 `fq=""` 实测是**前复权**（格力 2026-08-26：tdx `tqFlag=0`=41.58，westock=39.58，差正好 2.00 = 每股派息）。它拿不到真原材料，只能做校验。
2. **baostock 是唯一直接给"复权因子"的第三方**（`query_adjust_factor` → `dividOperateDate` / `foreAdjustFactor` / `backAdjustFactor`）。tdx 给的是前复权**价格**，只能反推因子；baostock 给的是**因子本身**。用它校验 `dividend` 表是目前唯一能独立验证因子公式的办法——不依赖价格、不依赖我们的 K 线。
3. baostock 的财务是**精选指标**（`query_profit_data` 的 `roeAvg`/`netProfit` 之类），不是完整三表，没有逐字段的 `OperatingRevenue`。只能校验量级，不能替代主源。
4. baostock 的 `query_history_k_data_plus` 字段里含 `peTTM` / `pbMRQ` / `psTTM`，日频、可拉十年 —— 这是校验东财估值序列的**唯一独立源**（东财的 `pb_mrq` 会被上游重算，见 `SCHEMA` §4.7）。
5. baostock 只有日频收盘，没有盘中快照，也没有换手率之外的实时字段。
6. **东财 `push2his` 的 `fqt=0` 无鉴权，且 raw 与 tdx 逐点同值**（2026-11-14 实测）。这就是矩阵里 `kline` 主源从 tdx 改成东财的全部理由——不是"东财更好"，是**它是唯一一条独立进程拿得到真原材料的通道**：一次请求给全历史（茅台 6042 行、2001-08-27 起），`fqt=0` 明确是不复权，`volume` 是手（×100 还原成股，茅台 2026-11-13 给 `41780` 手 vs tdx `41779.84` 手，误差 5e-7），`amount` 已是元。两个坑写进适配器注释了：**手→股要乘 100**（且上游已抹成整数手），**北交所 `43/83/87xxxx` 会返回 `name="诺思兰德(已切换)"` + `klines=[]`**，这是代码迁去 `92xxxx`，必须单独报 `code_moved`，否则会被记成一个永不消失的洞。逐点对照：

    ```
    格力   2026-08-26  tdx tqFlag=0 41.58   东财 fqt=0 41.58
    比亚迪 2025-07-28  tdx tqFlag=0 337.00  东财 fqt=0 337.00
    比亚迪 2025-07-29  tdx tqFlag=0 111.42  东财 fqt=0 111.42
    ```

    正因为 §4.1 早就判定"`kline` raw 跨源混得起"，这次换源**连 `fp` 都没动**，只需不覆盖已有 bar。
7. **tdx MCP 端点在独立进程里拿不到。** （2026-11-14 实测）宿主里的 tdx 连接器正常，但用 Python 直接 `POST` MCP 端点 `initialize`，返回：

    ```
    401 {"error": "unauthorized", ... "Missing Bearer authorization"}
    ```

    令牌由宿主进程持有，`stock_data_fetch` 作为独立 CLI 进程取不到。所以 tdx 保留为 `kline` **备源**，由 `sources/tdx.py` 的 `available()` 探测令牌文件，**没有令牌就整源从路由里摘掉**（`SourceSpec.reason`），router 不会白打 401。它给的数据质量确实最好（`RawVolume` 是股、`Amount` 是元、`tqFlag=0` 是真原材料），一旦令牌可读就自动回到可路由列表——**这是注册表里唯一一个"可用性靠探测而不是靠写死"的源**。
   > 顺带一个单位坑：tdx 的 `Rows.Volume` 是**手**（= `RawVolume/100`），`RawVolume` 才是股。取成交量的正确写法是 `RawVolume`，不是 `Volume × Unit`（`Unit` 字段并不可靠）。

> **矩阵里"备"最多的域是 `kline` 和 `quote`，这不是巧合**：这两类数据每家都有、口径差异最小（都是原始 OHLC），最适合做逃生通道。反过来 `finance` / `valuation` 的备源少，因为**口径差异大**——换源就可能换口径，这也是 §4.1 那条铁律存在的原因。

> **一个遗留的不对称**：`kline` 主源已经换成东财（脚注 ⁶），但"复权因子校验"那行的基准仍是 **tdx qfq 价格**，而 tdx 在 CLI 进程里拿不到（脚注 ⁷）。也就是说**§8 的 2 号探针目前跑不了自动化**——`纪要` §16 那次验证是手工调的宿主 MCP。第 4 步做 `factor.py` 时要么把探针降级为"手工季度跑"，要么等 baostock 能登录（脚注 2 的因子侧验证本来就比价格侧更硬）。**这条不影响 `factor.py` 的实现**：因子从 `dividend` 表算，不依赖任何源。

---

## 4. 三条铁律

### 4.1 换源要不要作废旧数据？——**不放 fp，放 meta**

先明确 `fp` 的唯一作用：**决定"库里的数据还能不能用"**。fp 变了 → 缓存失效 → 重取。所以"src 进 fp"能做的只有一件事：**我们换了源，就让旧数据作废**。

问题于是变成一句话：**换源后新旧数据混在一条序列里，出不出事？**

| 域 | 换源后混得起吗 | 需要作废吗 |
|---|---|---|
| `kline` raw | **混得起**。raw 就是交易所成交价，tdx / 东财 `fqt=0` / baostock `adjustflag=3` 拿的是同一个数，差异只在分位四舍五入 | 否 |
| `quote` / `snapshot` | 一股一行、每次覆盖，**不存在"混"** | 否 |
| `dividend` | 除权日是既成事实，两家不会给两个日期。**混不了**（真风险是"漏一次"，那是完整性问题，靠探针，fp 管不了） | 否 |
| `finance` | **有影响**。东财不直接给 `_Q` 与 TTM，切过去会出现"有的期有单季、有的期没有"，下游分不清是缺失还是口径不同 | 是 |
| `valuation` | **影响大**。分位是对尾部水平极敏感的统计量，混进一段另一家的 `PE_TTM`，十年分位会跳；且 `pb_mrq` 本身还会被上游重算（`SCHEMA` §4.7） | 是 |

**结论：`fp` 不加 `src`。** 改成用 `meta` 记"本域当前源"，在 `ensure` 里比一次：

```
需作废的域（valuation / finance）：
    cur = meta["domain_src:<domain>"]
    if cur and cur != router.pick(domain).upstream:
        → 该域视为全失效，整段重取，完成后写回 meta
其余域（kline / quote / dividend / snapshot）：
    不检查，换源只补洞与向前延伸，不覆盖已有区间
```

**为什么这样比塞进 fp 好**：

| | 塞进 `fp` | 放 `meta`（选这个） |
|---|---|---|
| 效果 | 换源 → fp 不符 → 重取 | 换源 → meta 不符 → 重取（**等价**） |
| `SCHEMA` §4.4 的 fp 表 | 要动 | **不动** |
| 粒度 | 全库一刀切 | **按域开关**（只有 2 个域需要） |
| 语义 | "口径指纹变了"（会让人以为上游改了口径） | "换源迁移"（本来就是这件事） |
| 应急成本 | 主源挂了切备源 → 立刻全量重取 | 同左，但**只在需要的域上付这个成本** |

**可追溯性不靠 fp**：知道"这段数是谁给的"由**行级 `src` 列**（kline / finance / valuation / dividend / quote / snapshot 全都有）+ `coverage.src` 承担；知道"发生过降级"由 `meta('source_degraded', ...)` 承担。`fp` 不是审计工具。

**另外加一条轻规则**：换源时**只允许补洞与向前延伸，不允许覆盖已有 bar**。否则两家的数会在"拼接期"被静默改写，而这件事 `fp` 和 `meta` 都拦不住，只能靠"不覆盖"这条纪律。

### 4.2 校验必须跨上游

`a.upstream != b.upstream` 是探针成立的前提。

| 探针组合 | 结果 |
|---|---|
| efinance vs 东财直连 | ❌ **假校验**：同源，误差恒 0，什么都验不出来 |
| akshare `stock_zh_a_hist` vs 东财 | ❌ 假校验（akshare 这条就是东财） |
| baostock vs 东财 | ✅ 真校验 |
| tdx vs westock | ✅ 真校验（已做过：复权双样本误差 0.00） |

这条不是洁癖。如果拿 efinance 去"验证"东财，跑出来 100% 一致，会得出"数据可靠"的结论——而实际上东财哪天字段口径改了，两边会一起改，探针永远不会报警。**同源校验会给出虚假的安全感，比没有校验更糟。**

### 4.3 开源库是**可选依赖**，只做校验和第三备

共享取数层是基础设施，四个工具都挂在上面。基础设施不能因为 `pandas` 升了个小版本就整体启动失败。

| 规则 | 做法 |
|---|---|
| 可选依赖 | `sources/akshare.py` 里 `try: import akshare except ImportError: AVAILABLE=False`，源自动从路由里摘掉，**主链路零影响** |
| 版本钉住 | `requirements-optional.txt` 里写 `akshare==x.y.z`，不写 `>=` |
| 不做主源 | 主源只用 MCP 与直连 HTTP（有官方维护、无第三方依赖） |
| 失败即禁用 | 某源连续 3 次抛异常 → 本次进程内禁用，记 `meta` |

**为什么开源库不做主源**：`akshare` 的函数名会随版本改（`stock_zh_a_hist` 这类名字历史上改过多次），`efinance` 跟着东财页面结构走，`baostock` 依赖 socket 长连接。它们都很好用，但"接口可能明天就变"这件事，落在一个人维护的共享库上就是灾难。做备源和校验源，价值最大、风险最小。

---

## 5. 开源库逐个定位

### 5.1 baostock —— 价值最高，定位「校验金标准」

三个不可替代的点：

1. **`query_adjust_factor` 直接给复权因子**（`dividOperateDate` / `foreAdjustFactor` / `backAdjustFactor`）。我们的 `factor(t) = Π r_d` 目前只用 tdx 的前复权**价格**间接验过；baostock 可以从**因子**这一侧独立验一遍。如果两边对得上，复权方案就是双基准验证，不再是单点。
2. **`query_history_k_data_plus` 含 `peTTM` / `pbMRQ` / `psTTM`**，日频、十年。这是校验东财估值序列的唯一独立源，也顺带能验"周频取 ISO 周最后交易日"这个组周规则。
3. **`query_trade_dates`** 独立给交易日历，可校准 westock 的日历与 kline-screen 的 json。

限制：财务是精选指标不是三表（只能验量级）；代码格式是 `sh.600519`（要转换）；socket 长连接需要 `login/logout` 生命周期管理，与"用完就退"的进程模型要适配。

**结论：接入，但只跑探针，不写主表。** 优先级排在主源之后，探针频率见 §8。

### 5.2 akshare —— 定位「逃生通道」

好处是覆盖面极广（财务、分红、龙虎榜、行业、宏观都有），坏处是**一个库里混着多个上游**：

| akshare 函数 | 实际上游 |
|---|---|
| `stock_zh_a_hist` | 东方财富 |
| `stock_zh_a_daily` | 新浪 |
| `stock_a_indicator_lg` | 乐咕乐股 |
| `stock_financial_report_sina` | 新浪 |

所以它**不能整体登记成一个源**，要按函数登记成 `akshare:em` / `akshare:sina` / `akshare:lg` 三个不同 `upstream` 的适配器。否则 §4.2 的校验规则会被绕过（用 `akshare:em` 去验东财，又是假校验）。

依赖 `pandas`，启动成本高。**结论：只登记 `akshare:lg`（乐咕估值，因为它是唯一非东财的估值源）与 `akshare:sina`（K 线逃生），其余不接。**

### 5.3 efinance —— 定位「东财的第二条通道」

上游与东财直连完全同源。它的唯一价值是**吞吐**：当东财直连的 400ms 节流成为瓶颈时，`efinance` 是另一条到同一数据源的通道，配额独立计算（实际上东财没有硬配额，只是反爬）。

**结论：只当吞吐备用，绝不参与校验**（§4.2）。优先级最低，默认关闭。

---

## 6. 配额与串行（已定：串行）

六个源分属**四条独立通道**，配额互不相干：

| 通道 | 源 | 计量 | 实测/现值 |
|---|---|---|---|
| A | westock | 返回行数 | ~15k 行/分钟（实测，`讨论纪要` §18.2） |
| B | eastmoney（直连 + efinance） | 返回行数 | 注册表 15k/min；**实际瓶颈是"连取 20 只后被掐连接"**（见下） |
| C | tdx | 未知 | 最小间隔定 300ms（未实测）；无批量；**独立进程拿不到令牌** |
| D | baostock / akshare | 未知 | 探针用，量极小；baostock 本机黑名单 |

**东财限频的实测形态（2026-11-14，这条比数字更重要）**：

| 现象 | 观测 |
|---|---|
| 触发 | 连续取 20 只左右（`beg=1990` 全历史，每只 3000–6000 行） |
| 报错 | `http.client.RemoteDisconnected` —— **直接掐 TCP，不返回 429/4xx** |
| 换 UA | 无效（照样断） |
| 拉大间隔到 1.0s / 1.5s | **仍然全断**（说明不是"速率滑窗"，是"今日配额用完"） |
| 静默几十秒后 | **恢复**（说明不是 IP 封禁） |

两个直接后果：

1. **`RemoteDisconnected` 是 `OSError` 子类，`URLError` 接不住。** 漏接的话会以一个"看不懂的异常"穿过 router 直达四个工具。适配器把它统一转成 `SourceUnavailable(transient=True)`。
2. **`transient` 不等于"源坏了"，要按限频处理：进冷却、等、重试同一源，不换源。** 换源等于把压力转给另一家，同时把数据换成另一家的口径（§7 第 4 条同理）。router 的 `_call()` 就是这条：三次仍断才抛 `ThrottleTimeout`（错误码 6）。

这也是 `kline` 首建**不能一上来就全市场跑**的实证依据：4300 只 × 全历史，东财一定会在第 20 只左右掐掉。按需取数（`ensure` 的语义）天然规避了这一点——四个工具单次只碰"候选池里的几十只"。

**已定：单线程串行，不做并行。**（2026-11-14 决定）

理由，按重要程度排：

1. **并行的收益是"快 3 分钟"，代价是排查成本翻倍。** 一旦出问题，要先证明"不是并发导致的"，而限频的长尾（`讨论纪要` §18.2：30–45s 静默都不一定够）会让并发与限频的因果关系极难分离——`SOURCES` 上一版的 `sync` vs `nosync` 对照就被污染过，没跑出干净结论。
2. **四个工具本身是串行跑的**，单次运行只需要"一只股票的几个域"，不是"全市场三个域同时拉"。真正需要并行的是全市场首建，而那是一次性的事（`kline` 半小时级，见下表），一次性成本不值得换来长期的排查复杂度。
3. **串行天然满足"节流器是唯一串行点"**（`CONTRACT` §7）。多线程后 `flock` 与令牌桶仍能工作，但"谁在等谁"从一条线变成一个图，日志与复现都变难。

串行不等于放弃通道抽象：`throttle.take(src, rows)` 本来就是按源计量的，注册表里每个源也带自己的 `Quota`。**将来真要并行，改的是 `api.py` 里一个循环的形状，不是数据结构**——前提是现在就把"按源配额"写对，而不是全局一个 1600ms。

**串行下的实际耗时**（全市场 ~4300 只，首建）：

| 域 | 源 | 单只 | 全市场首建 |
|---|---|---|---|
| `kline` 300 根 | 东财（**无批量**，只能逐只） | **实测 0.42s** | **约 30 分钟**（4300 × 0.42s，20 只实测外推） |
| `finance` 43 期 | westock（批量 150） | — | 约 10 分钟（15k 行/分钟配额下） |
| `valuation` 520 周 | 东财（逐只 + 翻页） | ~2s | **2 小时以上** |

> ⚠️ **两个已经实测出来的问题，都跟这张表有关。**
>
> **一、30 分钟这个数字是"不会被掐断"的前提下算的。** 实测 20 只连取之后东财就 `RemoteDisconnected`（见上表），所以 4300 只不可能一口气跑完——首建必然要分段 + 冷却。这不是靠"拉大间隔"能解决的（1.5s 间隔照样断），只能靠"跑一批、停一段"。
>
> **二、20 只样票里 6 只失败。** 3 只是停牌造成的缺口（已用 `coverage.settle()` 修：同一段取两次仍空就认账判 `permanent`，不再无限重试），3 只是空表（东财 `data: null`，多为代码不存在或已迁移）。后者已单独报 `code_moved` / `no_data`，但**"空表占 15%"这个比例得在全市场量级上再验一次**——如果成立，4300 只里会有几百只永远取不到，`ensure_many` 必须能跳过而不是整体失败。
>
> 应对，仍留到后面定：
> 1. **不预热全市场**。四个工具里 kline-screen 要全市场，但它自己本来就有缓存与分批；judge/quality 只要候选池。`ensure` 的按需语义本来就支持"用到才取"，别为它做全市场预热。
> 2. 真要压时间，只有两条路：**找到东财的真实配额上限然后贴着跑**，或者**接受"由 westock qfq 反推 raw"**（`raw(t) = qfq(t) × f(T)/f(t)`，f 来自 `dividend`）。后者能把批量拿回来，但 raw 就成了派生量，违背"只存上游原值"这条不变式——要不要破，是一个需要单独决定的问题，不在本文件里定。
>
> `valuation` 2 小时那格同理：`quality` 只跑候选池（几十只），**不要把 `valuation` 纳入全市场预热**。

---

## 7. 健康度与自动降级

```
router.order(domain) 的顺序规则：
  1 该域所有 AVAILABLE 且未被禁用的源，按 priority 升序
  2 冷却中的源**排到后面**（不是摘掉）；全都冷却就**不排序，等** ——
    throttle.take() 会自己睡到冷却结束
  3 主源连续 3 次失败 → 本次进程内降级，记 meta('source_degraded', ...)
  4 主源可用但返回 partial → **不降级**，走组级重试（换源解决不了限频）
  5 返回 transient（掐连接/超时/5xx）→ **按限频处理**：冷却 + 重试同一源，
    不换源；连断 3 次才抛 ThrottleTimeout（码 6）
```

第 4、5 条容易搞错：**限频不是"源坏了"，换源等于把压力转给另一个源，同时把数据换成另一家的口径。** 只有"源不可达 / 接口变更 / 持续空表"才降级。

第 2 条是**实机踩出来的**：第一版写成"主源冷却中 → 跳过"，结果主源一进 300s 冷却，整批 20 只股票集体报"没有可用源"——明明等 5 分钟就能取。**冷却的语义是"慢一点"，不是"不能用"**，这两件事混在一个分支里，故障面就从"变慢"扩大成"全部失败"。现在改成：冷却中的排到后面，一个都不剩就干等（`take()` 的 sleep 正是为此存在）。

降级发生时必须写 `meta`：`{"domain":"finance","from":"westock","to":"eastmoney","reason":"...","at":"..."}`。不写的话，三个月后没人知道库里这段数是哪来的。

> 另有一条不是"降级"但要记的：**空表**。东财 `data: null` 与 `klines: []` 都返回 200，20 只样票里占 3 只。它不是源坏了，是"这只票这个域本来就没有"，走 `empty_reason`（`no_data` / `code_moved` / `new_stock` / `suspended`），由 `coverage.settle()` 决定记成洞还是认账。

---

## 8. 校验探针

只做抽样，不每只跑（每条探针都要花配额）。

| # | 探针 | 组合（必须跨上游） | 判据 | 频率 |
|---|---|---|---|---|
| 1 | 复权因子 | **baostock** `adjust_factor` vs 自算 `factor(t)` | 逐除权日相对差 < 1e-6 | 每月 / 每次改因子代码后 |
| 2 | 复权价格 | tdx qfq vs 自算 qfq | 逐点 < 0.01（已验证） | 每次改因子代码后 |
| 3 | 财报量级 | westock vs 东财，同期 `OperatingRevenue` | 相对差 < 1e-6 | 每季度财报季后 |
| 4 | 估值口径 | **baostock** `peTTM` vs 东财 `PE_TTM`，同交易日 | 相对差 < 2%（口径细节可能不同） | 每季度 |
| 5 | 交易日历 | westock vs **baostock** `trade_dates` | 集合完全相等 | 每年初 |
| 6 | 停牌判定 | tdx 无 bar 日 vs westock `data_suspension` | 一致 | 遇到 `permanent` 洞时 |

探针跑在 `python -m stock_data_fetch probe`，**只读不写**，结果进 `doctor` 报告。

---

## 9. 实现形态

```python
# sources/base.py（已实现）
@dataclass(frozen=True)
class SourceSpec:
    name: str                 # westock / tdx / eastmoney / baostock / akshare_lg / efinance
    upstream: str             # tencent / eastmoney / tdx / baostock / legulegu  ← fp 用这个
    transport: str            # mcp / http / lib
    domains: tuple[str, ...]  # ("kline","finance","quote","profile","calendar")
    priority: int             # 同域内 0 = 主源
    batch: int                # 单次最大 codes；1 = 无批量
    quota: Quota = Quota()    # rows_per_min 或 min_interval_ms
    optional: bool = False    # True = 依赖缺失时静默摘除
    reason: str = ""          # 非空 → 注册表过滤掉它，doctor 原样打印
```

> `check_with` 那个字段**没有实现**。原设计想让它"自动生成探针组合"，实际做法是探针表（§8）手写、上游名硬编码——组合只有 6 条，自动生成是过度设计。`upstream` 字段本身已经足够表达"能不能互校"。

注册表在 `sources/__init__.py` 里硬编码一张列表（不搞插件自动发现——源就六七个，显式列表更好审查）。**2026-11-14 起 `kline` 的主源是 `eastmoney`**：

```python
SOURCES: list[SourceSpec] = [
    SourceSpec("eastmoney", "eastmoney", "http", ("kline", "valuation", "finance", "snapshot"),
               priority=0, batch=1, quota=Quota(rows_per_min=15000.0)),
    SourceSpec("tdx", "tdx", "mcp", ("kline", "quote", "profile"),
               priority=1, batch=1, quota=Quota(min_interval_ms=300.0)),
    SourceSpec("westock", "tencent", "mcp",
               ("kline", "finance", "quote", "profile", "dividend", "snapshot", "calendar"),
               priority=1, batch=150, quota=Quota(rows_per_min=15000.0)),
    SourceSpec("baostock", "baostock", "lib", ("kline", "valuation", "calendar"),
               priority=9, batch=1, quota=Quota(min_interval_ms=200.0), optional=True,
               reason="未接入（本机 bs.login 返回 10001011 黑名单用户）"),
]
```

`MODULES = {"eastmoney": …, "tdx": …, "westock": None, "baostock": None}`，`None` = 适配器还没写。`available(domain)` 的关键一步是 `_reason(spec)`：

- `spec.reason` 非空 → 直接摘掉（写死的"这个东西现在不能用"）；
- 适配器模块有 `available()` 就叫一次（**tdx 靠这条探测令牌**，没令牌返回原因）；
- 否则认为可用。

这样"源不可用"只有一种表达，`doctor` 打印 `disabled()` 就能回答"这次为什么没用 tdx"。

`fetch()` 的统一契约（三层之间唯一接口）：

```python
def fetch(domain: str, codes: list[str], need) -> Got
# Got:
#   rows: dict[str, list[Row]]     按 symbol 分行
#   errors: list[BatchError]        组级失败（§CONTRACT 7.3），**有上游自报就用上游的**
#   empty_reason: str | None        "no_data" / "code_moved" / "param_error" / "new_stock" / "suspended"
#   meta: dict                      pages / currency / unit
```

适配器的四条硬约束（`base.py` 里写进 `FetchFn` 的 docstring 了）：**不许 sleep**（节流归 throttle，适配器里睡会绕过令牌桶）、**不许写库**（写库必须在覆盖记录的同一个事务里）、**空表必须给 `empty_reason`**、**单位换算在适配器里做完**（库里只存"元 / 股 / 每股"）。

**`empty_reason` 这个字段是新增的**：六个源里有四个会在参数写错时返回空表而不报错（`CONTRACT` §7.4 已实测东财/腾讯两种）。适配器必须自己判断"空"的三种原因，否则上层无法区分"停牌"和"我传错了参数"。

---

## 10. 依赖策略

| 项 | 做法 |
|---|---|
| 主依赖 | **仍然只有标准库**。`stock_data_fetch` 主链路不许 `import pandas` |
| 可选依赖 | `requirements-optional.txt`：`baostock==0.8.9`、`akshare==<pin>`、`efinance==<pin>` |
| 缺失处理 | 适配器模块级 `AVAILABLE = False`，注册表过滤掉；`doctor` 打印"已禁用的源" |
| 版本升级 | 只有探针通过才允许改 pin；改 pin 必须重跑 §8 的 1/4/5 号探针 |
| 隔离 | 每个开源适配器单独一个文件，**不允许主链路 import 它的任何名字** |

最后一条是关键：`sources/akshare_lg.py` 崩溃或缺失，`sources/__init__.py` 仍然能把其他五个源装配起来。这样"加一个开源源"的风险上限是"这个源被禁用"，不是"整个数据层起不来"。

---

## 11. 待实测 / 未决

| 项 | 现状 | 何时定 |
|---|---|---|
| **baostock 能否用** | ❌ **2026-11-14 实测：`login()` 返回 `黑名单用户`**，本机不可用 | 换网络/换机器时再试；在此之前 §3 的两个"验"降级为"待验" |
| baostock 的 `adjust_factor` 字段名与因子方向 | 未能实测（登录就被拒） | 能登录时第一件事 |
| baostock 数据更新到哪一天 | 同上 | 同上 |
| akshare / efinance 的 pin 版本 | 未定 | 接入时先定版本号再接入 |
| `fp` 是否加 `src` | **已定：不加**。改用 `meta['domain_src:<domain>']` + 按域整段重取（§4.1） | — |
| 交易日历是否改用 westock 为主 | 仍**不进库**；`preflight` 只做本地自检，跨源对账在 `probe`（`CONTRACT` §4.4） | 待做 |
| 通道并行 | **已定：串行**（§6） | — |
| `kline` 主源 | **已定：eastmoney**（`fqt=0` 无鉴权、与 tdx 逐点同值）⁶⁷ | — |
| tdx 令牌能否被 CLI 进程读到 | ❌ 实测 401。`sources/tdx.py` 的 `available()` 探测令牌文件，读不到就整源摘除 | 宿主以后若把令牌落盘，改一行即可自动启用 |
| 东财真实配额上限 | ❌ 未知。只测出"连取 20 只左右被掐、1.5s 间隔照样掐、静默几十秒恢复" | 长跑校准（跑一批停一段，二分找上限） |
| 东财空表比例 | ⚠️ 20 只样票里 3 只空表（15%），其中含北交所迁移代码 | 全市场量级再验；若成立，`ensure_many` 必须能跳过而不是整体失败 |
| `kline` 全市场首建耗时 | 单只 **0.42s** 实测，外推 **约 30 分钟**；但被东财掐断打断，不可能一口气跑完 | 首建时实测；若不可接受，再议"贴着配额跑"或"westock qfq 反推 raw" |
| 停牌股的段级重试次数 | 认账要靠 `coverage.settle()`，但它会多重试一次（整段 + 缺口段共 3 次调用） | 已接受并写成测试断言；量级不大，不值得再优化 |
| 备源要不要第一版就实现 | 建议只留接口，不实现 | 第二版 |

---

## 12. 与其它文档的差异

| 位置 | 旧说法 | 本文件 |
|---|---|---|
| `SCHEMA` §3.1 写者表 | 每域一个写入者 | 每域一个**上游**，可有多条传输。写者仍是 `stock_data_fetch`，但 `coverage.src` 记上游 |
| `SCHEMA` §4.4 fp 表 | `type`/`fields`/`freq` | **fp 不变**。换源作废改用 `meta['domain_src:<domain>']`，只对 `valuation` / `finance` 生效（§4.1） |
| `CONTRACT` §6 `ensure` 流程 | 无"换源"概念 | 补一步：`meta.domain_src` 与当前路由源不符 → 该域整段重取（仅 2 个域） |
| `CONTRACT` §7.5 | 三源差异表 | 扩到六源，且区分「同上游不同传输」不可用于校验（§4.2） |
| `CONTRACT` §12 配置 | 按 `src`（传输名）配速率 | 补按上游聚合的说明：同上游多传输共享一份数据、但配额独立 |
| 纪要 §18 | 只测了 westock | 东财/tdx/baostock 的限频仍未知（§11） |
| 纪要 §16.4（tdx 完全可用） | "通达信可用" | 仅**宿主里**可用；CLI 进程 401（脚注 ⁷）。§3 矩阵据此把 `kline` 主源改东财 |
| 本文件 §3 旧版（`kline` 主 = tdx） | "只有 tdx 给真原材料" | 东财 `fqt=0` 也是真原材料，且逐点同值（脚注 ⁶）。"只有 tdx"是**没查到东财 `fqt=0` 时的结论**，已作废 |
