# 共享库 Schema 设计

- 日期：2026-11-14
- 状态：**设计定稿，DDL 已通过建库验证（11 表 / WAL / auto_vacuum=INCREMENTAL）**
- 配套脚本：`schema.sql`（可直接执行建库）
- 上游依据：`讨论纪要-共享数据层.md`（§4 口径表、§13 复权方案、§14 决策清单、§16 实测）

> 这份文件回答三件事：**表怎么建**、**命中怎么判**、**四个工具怎么接**。
> 口径依据不在这里讨论（去纪要），这里只落实现。

---

## 1. 定位与三条不变式

**定位**：按需读写、单文件、无 daemon 的本地数据层。四工具只读，`stock_data_fetch` 是唯一写者。

改任何 DDL 之前先看这三条，它们决定了绝大多数设计取舍：

| # | 不变式 | 违反后的后果 |
|---|---|---|
| **1** | **只存不复权的原始值** | 存前复权 → 每次除权整段失效；存后复权 → 与上游对不上，且因子无处可校 |
| **2** | **财报/分红 append-only：只增期，不删期** | 上游只回 43 期，删掉的期永久补不回来（§4.1） |
| **3** | **数据写入与 coverage 更新必须同一事务** | 分开写 → "数据有了、水位没记" → 下次重取；更糟是"水位有了、数据没写" → 误判完整，永久缺数据 |

---

## 2. 全局规范

### 2.1 证券标识

统一用 `symbol` 作为唯一键，格式 `市场前缀 + 6 位代码`：

| 市场 | symbol | exch | setcode（通达信用） |
|---|---|---|---|
| 上交所 | `sh600519` | `SH` | `1` |
| 深交所 | `sz000858` | `SZ` | `0` |
| 北交所 | `bj430047` | `BJ` | `2` |

- **为什么不只用 6 位数字**：`000001` 同时是平安银行（深）和上证指数（沪），裸数字必然踩坑。
- **为什么不存两套**：`setcode` 作为列冗余存一份，调 tdx 时直接用，不做二次推断。

### 2.2 日期

- 一律 `TEXT`，格式 `YYYY-MM-DD`。字符串比较即时间比较，`ORDER BY` 天然正确，dump 时可直接读。
- **不用** `YYYYMMDD` 整数：省 6 字节/行，但每次查询都要格式化，人工排查时看不懂。
- `period` 是**报告期末**（`2026-09-30`），不是公告日；公告日只在 `raw_json` 里。

### 2.3 单位（最容易出错的一节）

| 字段 | 单位 | 换算说明 |
|---|---|---|
| `kline.volume` | **股** | 通达信 `Rows.Volume` 是"手"，入库 ×100 |
| `kline.amount` | 元 | 原值 |
| `quote.float_shares` / `total_shares` | **股** | 换手率 = `volume / float_shares`，同单位直接除 |
| `dividend.*_per_share` | **每股** | 上游给"每 10 股"，入库 ÷10 |
| `finance.*` | **元**（已实测） | 本源 `data_finance` 返回的就是元；其他源若是万元，**入库前换算成元**，`unit` 只做标识 |
| `valuation.total_mv` / `circ_mv` | 元 | — |

> **成交量单位是踩过的坑**：通达信返回 `Volume=786540`、`RawVolume=78654040`、`Unit=100`。取 `Rows.Volume` 再 ×100 得股数；**不要**再按 `Unit` 二次换算（官方明确警告过）。

### 2.4 浮点与 NULL

- 价格用 `REAL`。比较时用**相对容差 1e-6**，不要用 `=`。
- `NULL` 表示"该期该字段上游没给"，**不等于 0**。`0` 表示"上游明确给了 0"。
- 财报里某期只有利润表、没有资产负债表时，行仍然存在，balance 字段为 `NULL`——所以**命中判定不能只看行数**（见 §4.4）。

### 2.5 "当期"的定义

`quote` / `snapshot` 这类快照型，`trade_date` 必须等于**目标交易日**（交易日历上 ≤ now 的最后一个已收盘交易日）。判断过期用 `stored.trade_date <> target`，**不用**时间差（长假会误判、周日取的数据周一早上只差 12 小时却已过期）。

---

## 3. 表总览

| 表 | 域 | 粒度 | 每只股票行数 | 可再生性 | 清理策略 |
|---|---|---|---|---|---|
| `stock` | profile | 一股一行 | 1 | R | 跟股票走 |
| `kline` | kline | 一股一日 | 300 | **R** | 滚动 300 根 |
| `finance` | finance | 一股一期 | 43 | **W** | **不删** |
| `finance_revision` | finance | 一股一期一字段 | 0～几条 | W | 不删 |
| `dividend` | dividend | 一股一除权日 | 10–30 | **W** | **不删** |
| `valuation` | valuation | 一股一周 | 520 | **R** | 修剪 >10 年 |
| `quote` | quote | 一股一行 | 1 | **S** | 覆盖 |
| `snapshot` | mainop/consensus/rating | 一股一域 | 3 | **S** | 覆盖 |
| `coverage` | — | 一域一股一口径 | ~6 | 派生 | 跟股票走 |
| `watermark` | — | 一域一范围 | — | 派生 | — |
| `meta` | — | 键值 | — | — | — |

**R / W / S 的含义**：R 是"删了能重取"，W 是"上游窗口滚动、删了就永久消失"，S 是"上游不留历史、错过就没有"。三者清理策略必须分开写（纪要 §5 规则 7）。

### 3.1 谁读谁写

| 表 | 写入者 | 读者 |
|---|---|---|
| `stock` | stock_data_fetch | 四工具全部 |
| `kline` | stock_data_fetch（tdx） | kline-screen、judge-top |
| `finance` | stock_data_fetch（东财） | cycle-elastic、quality-screen、judge-top |
| `dividend` | stock_data_fetch | judge-top（算复权因子） |
| `valuation` | stock_data_fetch（东财） | quality-screen |
| `quote` | stock_data_fetch（tdx/westock） | kline-screen、quality-screen、judge-top |
| `snapshot` | stock_data_fetch | quality-screen、cycle-elastic |
| `coverage` / `watermark` | **仅 stock_data_fetch** | 仅 stock_data_fetch |

> 四个工具**一律不写库**（包括不写 `last_access_at` 之外的东西）。`stock_data_fetch` 是唯一写者，这句话要能靠代码审查验证。

---

## 4. 逐表设计要点

### 4.1 `kline` —— 为什么存"股"而不是"手"

`volume` 入库即 ×100 换成股。理由：`quote.float_shares` 也是股，换手率一句 `volume/float_shares` 就出来，不用在每个消费点记换算。代价是入库时一处 ×100——**一处好过十处**。

深度 300 根（纪要 §14.1-2 已定）。滚动删除，`DELETE FROM kline WHERE symbol=? AND date < ?`。

### 4.2 `finance` —— 一期一行，三表字段并排

**这是本 schema 最关键的一个取舍。** 三种做法：

| 做法 | 优点 | 缺点 |
|---|---|---|
| 三张表（income/balance/cashflow） | 结构清晰、字段不串 | cycle 要同期 join 两表；"三表期数是否一致"要做三次检查 |
| 长表（symbol, period, field, value） | 加字段零成本 | 43 期 × 60 字段 = 2580 行/股，查询要 pivot，TTM 计算写起来痛苦 |
| **一期一行（选这个）** | 一次 `SELECT` 拿全三表；期数一致性天然保证（一行就是一期） | 宽（~45 列），字段稀疏 |

选它的直接原因：**四工具的用法全是"按期取三表"**——cycle 要 40 个 TTM 点（每点要 revenue/cost/profit + fixed_asset/CIP）、judge 要 6 期、quality 要 20 期做分位。没有谁是"只要现金流量表"的。一期一行让这些查询都变成一句话。

**存三组上游原值：累计 / 单季 `_Q` / `TTM`**

一开始的设计是"只存累计，单季由 `stock_data_fetch` 差分"。实测后推翻——上游本来就给单季和 TTM：

```
期间          累计营收(亿)   单季_Q(亿)   TTM(亿)
2025-12-31      1688.38      403.84     1688.38
2026-06-30       907.03      367.94     1701.52
2026-09-30      1309.71      402.67     1713.55

单季可加性：2026 年 Σ_Q = 1309.71 ＝ 年末累计 1309.71   差 0.000
TTM 自洽：自算(累计+去年年报−去年同季) vs 上游 TTM       差 0.0000%
```

**为什么改**：差分要求相邻期齐全，而 43 期是零余量——只要缺一期，整条 TTM 链就断。上游既然给了，且与差分结果一致（差 0.01 亿是四舍五入），就没理由自己算。

**"库里只存一种口径"这条原则仍然成立**，只是含义更严格了：**库里只存上游给的量，不存任何我们自己派生的量**。累计、`_Q`、`TTM` 都是上游原值，属于允许；"我用累计减出来的单季"才是禁止的。

对应的列：`OperatingRevenue` / `_Q` / `TTM`，`OperatingCost` 与 `OperatingProfit` 同理；资产负债表项（`TotalFixedAsset` / `CIP` / `ContractLiability`）没有单季和 TTM 的概念，只有一列。

**`raw_json` 只留最近 2 期**：全量留会到 5.7GB（纪要里算过），而它的作用只是"将来要加列时不用重取"——最近 2 期足够验证字段名。

### 4.3 `dividend` —— 复权的唯一来源

字段全按"每股"存（上游每 10 股 ÷10）。已实测确认口径（比亚迪 10派39.740元送8.000股转12.000股 → cash 3.974 / bonus 0.8 / transfer 1.2，除数 3.0 与 tdx 前复权吻合）。

因子公式（消费侧算，不落库）：

```
P_ref(d)  = (P_prev - cash + rights × rights_price) / (1 + bonus + transfer)
r_d       = P_prev / P_ref(d)
factor(t) = Π_{d ≤ t} r_d              后复权因子，只增不减
前复权价  = raw(t) × factor(t) / factor(T)
```

**库里绝不放前复权价**：它每来一次新除权就整段变，属于"会失效的东西"。

### 4.4 `coverage` —— 命中的唯一依据

一行 = 一个（域，股票，口径）的**已覆盖区间**。`fp` 是口径指纹：

| 域 | fp 内容 | 为什么 |
|---|---|---|
| `kline` | `fq=raw` | 复权形态不可叠加 |
| `finance` | `type=all;fields=all` | 单季/累计形态不同 |
| `valuation` | `freq=week` | 日频与周频不可混 |
| 其余 | `''`（空串） | 口径单一 |

> **fp 里不放 `src`**（2026-11-14 定，理由见 `SOURCES-数据源路由.md` §4.1）。`fp` 只描述**口径形态**，不描述**谁给的**——"谁给的"由 `coverage.src` 与各行 `src` 列记录，那是审计问题，不是缓存有效性问题。
>
> 换源要不要作废旧数据，用 `meta['domain_src:<domain>']` 判断，且**只对 `valuation` / `finance` 生效**：这两个域换源等于换口径（东财不直接给 `_Q`/TTM；估值分位对尾部水平极敏感）。`kline` / `quote` / `dividend` 换源不作废——raw 价格、单点快照、除权日都不因换家而变，强制重取只会让应急切换变贵。

`num` / `limit` **不进 fp**（纪要 §5 规则 3）——深度由 `start_date`/`end_date`/`n` 表达，是可叠加维度。

**`holes` 的定义**：用独立交易日历，把 `[start_date, end_date]` 内应有的交易日与库内实际日期做差集，**连续段算 1 个 hole**。明细存 `hole_detail`。

> 交易日历**不进库**，由 `stock_data_fetch` 加载 `stock-kline-screen-tool/database/trading_calendar.json`（13KB）。理由：日历是"规则"不是"数据"，进库就要维护更新，反而多一个失效点；且它不随股票变化，常驻内存即可。
>
> 但日历**错了会连锁**（所有 hole 判定、快照过期判定都基于它），所以 `preflight` 时用 westock `data_trade_calendar` 校准一次（提案，见 `SOURCES` §3）：只校验"今年交易日集合是否与 json 一致"，不一致就 `HubNotReady` 并提示更新 json，**仍不落库**。

### 4.5 `finance_revision` —— 覆盖要留痕

`finance` 允许上游更正覆盖（同一 `(symbol, period)` 的数值可变），但每次真变都写一行。判据：**相对差 > 1e-6** 才算修订，且**排除** `UpdateDate` / `InfoPublDate` / `AnnouncementDate`（这三个每次取数都在变，拿来比等于每次全量"修订"）。

### 4.6 `snapshot` —— 为什么不给 mainop/consensus/rating 各建表

这三个域的共同点：**只被 quality 一家消费、字段随上游变、当期一份**。给它们建三张固定列的表，等于以后每次上游加字段都要 `ALTER TABLE`——而它们本来就没有共享价值。

用 `(symbol, domain, payload JSON)` 一张表收起，代价是查询要解析 JSON（一次性小数据，无所谓）。

> 这不违背"SQLite 优于 JSON"的结论：大表（K 线 150 万行、财报 13 万行）全部结构化列存；JSON 只用于"字段不稳定 + 数据量极小"的边角域。

**`as_of` 的语义按 domain 固定**——这是最容易混的一处：

| domain | `as_of` 含义 | 依据 |
|---|---|---|
| `mainop` | **报告期末**（`2025-12-31`） | quality 的 `_mainop(calls, annual)` 取 `annual[0]["date"]`，返回 `{"period": "2025-12-31"}`。主营构成是按报告期披露的，不存在"某交易日的构成" |
| `consensus` / `rating` | **目标交易日** | 一致预期与评级是"当期快照"，隔一天就换 |

一个列装两种含义是刻意的：拆成 `trade_date` + `period` 两列，每行必有一半是 NULL，所有查询都得写 `COALESCE`。

### 4.7 `valuation` —— 列名必须带口径后缀

quality 读的是 `PE_TTM` / `PB_MRQ` / `PS_TTM`（`compute.py:419-421,480,501-503`），所以列名直接写成 `pe_ttm` / `pb_mrq` / `ps_ttm`，**不叫 `pe` / `pb` / `ps`**。

理由：V 分是分位计算，只要口径稳定就不会跳。但如果列名叫 `pe`，将来任何人塞进一个静态 PE，V 分会静默变化且事后查不出原因。**列名即契约**，把口径写进名字里，比写在注释里可靠。

**一个必须知道的例外**：`pb_mrq` 的分母是"最新报告期净资产"，**新财报一出，上游会把整段历史 PB 重算**。所以：

- `valuation` 是**唯一"历史值可能被上游重算"的域**，不能享受"写入即永久有效"的待遇；
- 允许整段覆盖刷新（`INSERT OR REPLACE` 全区间），`coverage` 不承诺旧值永久有效；
- 建议每季度财报季后强制重取一次（`ensure` 支持 `force=True`）。

---

## 5. 命中判定

```
hit(cov, need) :=
      cov 存在
  AND cov.fp         == fingerprint(domain)
  AND cov.partial    == 0
  AND cov.end_date   >= need.end
  AND blocking_holes(cov) == 0        ← 只数非 permanent 的洞
  AND cov.n          >= need.min_*    ← 深度只由点数表达
  ── 仅 dividend ──
  AND cov.start_date <= need.start    ← 唯一看 start 的域
```

三处与初稿不同，都是实现（`CONTRACT` §16 第 2 步）时定下的：

| 初稿 | 现在 | 原因 |
|---|---|---|
| `holes == 0` | `blocking_holes == 0` | 停牌股的洞永远不会消失。按 `holes==0` → 永远不命中 → 每次跑白打一次上游还要等 168 小时。`permanent` 洞仍计入 `coverage.holes`，只是不阻塞 |
| `start_date <= need.start` | **不看 start** | 次新股永远凑不满"回溯 300 根"，按 `start` 判会让它每次运行都重取一次、永远不命中。"够不够用"由 `min_*` 表达，`start` 只是取数范围的起点 |
| — | `n >= need.min_*` | 门槛由**调用方**声明：quality 20 期、cycle 40 期、judge 6 期。混在一起就会重犯"20 期刚好过 MIN_QUARTERS_REQUIRED 却静默降级"的老坑 |

**绝不判断"表里有没有这只股票的行"**。理由：有行不等于覆盖够——`finance` 可能只有 20 期（够 quality，不够 cycle），`kline` 可能只有 207 根（够 kline-screen，不够 judge）。判断错了不会报错，只会安静地输出一份"看起来正常"的报告。

---

## 6. `ensure()` 流程

```
def ensure(domain, symbol, need):
    fp  = fingerprint(domain)
    cov = read_coverage(domain, symbol, fp)
    if hit(cov, need):
        touch_access(symbol)
        return read_range(domain, symbol, need)

    with flock(f"{domain}:{symbol}"):          # 按 (域,股票) 分片，避免两个工具双取
        cov = read_coverage(domain, symbol, fp) # 双检（等锁期间别人可能已经填好）
        if hit(cov, need):
            return read_range(domain, symbol, need)

        got = fetch_upstream(domain, symbol, need, missing_of(cov))
        if got.partial:                         # 限频截断：60 只只回 10 只
            mark_partial(domain, symbol, fp)    # 不推进 end_date
            raise PartialData(symbol, got.got_n, got.want_n)

        with tx():                              # 见 §7
            write_rows(got)
            merge_coverage(cov, got)
            upsert_watermark(domain, scope, got.max_date)

    cov = read_coverage(domain, symbol, fp)
    if not hit(cov, need):
        raise InsufficientDepth(domain, symbol, need, cov)   # 不许降级
    return read_range(domain, symbol, need)
```

**三条硬规则**：

| 规则 | 原因 |
|---|---|
| 拿不到深度就 `raise`，**不返回部分数据** | 返回部分数据 = 让工具出"看起来正常"的报告，这是最坏的结果 |
| `partial` 时不推进 `end_date` | 否则下次命中判定会认为"这段已完整"，永久缺数据 |
| 锁的粒度是 `(domain, symbol)` | 全局锁会让四个工具串行；不锁会让同一只被取两遍，把限频放大一倍 |

`merge_coverage` 只增不减：

```
new.start = min(old.start, got.start)
new.end   = max(old.end,   got.end)
new.n     = count_rows(domain, symbol)
new.holes = recount_holes(...)      # 用交易日历重算，不靠增量累加
```

---

## 7. 写入事务

```
BEGIN IMMEDIATE          -- 立刻拿写锁，避免读->写升级时的死锁
  INSERT OR REPLACE ...  -- 批量，先在内存算完
  （finance 走"先 SELECT 比差异 -> UPDATE + 写 revision"）
  INSERT OR REPLACE INTO coverage ...
  INSERT OR REPLACE INTO watermark ...
COMMIT
```

- `BEGIN IMMEDIATE` 而不是 `BEGIN`：WAL 下 `DEFERRED` 事务在写时可能遇到 `SQLITE_BUSY` 且**不能安全重试**。
- 一次事务写完一批（一只股票 × 一个域），不要"一行一事务"——几千次 fsync 会把 7 分钟变成半小时。
- 跨进程的串行点是**节流器**（flock + "下次允许调用时刻"文件），不是数据库。数据库只负责不冲突。

---

## 8. 各域的 need 规格

| 域 | need 形态 | 深度 | 消费者 |
|---|---|---|---|
| `kline` | `(end_date, bars=300)` | 300 根 | kline-screen（71）、judge-top（250） |
| `finance` | `(periods=43)` | 43 期（上游上限） | cycle（40 TTM 点）、quality（20）、judge（6） |
| `dividend` | `(since=kline 起点 - 1 年)` | 覆盖 K 线全程 | judge-top |
| `valuation` | `(years=10)` | 520 周 | quality-screen |
| `quote` | `(target_date)` | 当期 | kline-screen / quality / judge |
| `stock`（profile） | `latest` | 当期 | quality / cycle |
| `snapshot` | `latest` | 当期 | quality / cycle |

> `dividend` 的 need 起点要比 `kline` 再往前一年：否则"最新一根 K 线之前最近的一次除权"会漏掉，导致因子少乘一次。

---

## 9. GC 与保留

| 表 | 策略 | 触发时机 |
|---|---|---|
| `kline` | 每股保留最近 300 根 | 每次写入后 |
| `valuation` | 每股保留 10 年（520 周） | 每次写入后 |
| `finance` / `dividend` | **不删** | — |
| `quote` / `snapshot` / `stock` | 覆盖，不增长 | — |
| 股票级清理 | `last_access_at` 早于 90 天 → 删该股的 `kline`/`valuation`，保留 `finance`/`dividend` | 库体积 > 800MB 时 |

清理粒度是**股票**，不是表。理由：删半只股票的数据会造出 `coverage` 与实际不一致的状态，而要修这个状态就得重取——等于白删。

删完执行 `PRAGMA incremental_vacuum`（`auto_vacuum=INCREMENTAL` 已在建库时设好，否则空间不会归还文件系统）。

---

## 10. 建库 / 迁移 / 备份

### 10.1 建库

```bash
sqlite3 ~/MyData/stock-data-hub/shared.db < schema.sql
```

首次建库由 `stock_data_fetch.preflight()` 自动完成——工具第一次跑就会建好，不需要人工步骤。

### 10.2 迁移

**策略：版本不符直接拒绝启动**（已定，纪要 §14.1-4）。

```
if PRAGMA user_version != EXPECTED:
    raise SchemaMismatch(f"库版本 {cur}，期望 {EXPECTED}；请备份后 rm + 重建")
```

理由：数据全部可再生（全市场重建约 7–8 分钟），写迁移脚本的成本远高于重建，而迁移脚本本身是 bug 来源。

### 10.3 备份

每日一次 `VACUUM INTO`，保留 2 份：

```sql
VACUUM INTO 'backup/shared-20261114.db';
```

`VACUUM INTO` 是原子快照，比 `cp` 安全（`cp` 可能拷到正在写的页）。

### 10.4 体检

`stockhub doctor`（只读）：打印 `user_version`、各域最新日期、`holes` 非零的股票、`partial=1` 的记录、表体积。**一个字节都不写**。

---

## 11. 四个工具的改造点对照

| 工具 | 现在取什么 | 改成 | 代码位置 |
|---|---|---|---|
| **kline-screen** | westock 批量全市场 → `database/*.json` | K 线写库通道换 tdx；或保留自取自用、结果顺带写库 | `kline_screen/datasources/kline.py` |
| **quality-screen** | westock `finance`/`quote`/`profile` | 这三个改读库；5 个独占域（估值/主营/capex/一致预期/评级）仍自取 | `screen/fetch.py:147-148` |
| **judge-top** | westock kline qfq + `finance num=60` + 3 段循环 | 读库 raw + 本地乘因子；finance 取 6 期；**`CACHE_VERSION` 3→4** | `judge/data.py:14,60-103` |
| **cycle-elastic** | westock `finance num=44` | 读库 43 期 | `cycle/fetch.py` |

**验收**（纪要 §14.2-10）：抽 30 只，改造前后各跑一次，数值全等（float 用 1e-9 相对容差）。HTML 只比关键数字，不比样式。

---

## 12. 口径裁定（4 条全部已定，附依据）

这 4 条原本是"待确认"，现已按"工具拿它干什么"逐条裁定，并全部落到 DDL 上。

### 12.1 `finance` 金额单位 = 元

实测：`data_finance(sh600519, 2026-09-30)` 的 `OperatingRevenue = 130,970,743,649.04`。茅台 2026 前三季营收 1309.7 亿元 —— 只有"元"才解释得通；若是万元就是 1.3 亿亿元，荒谬。

**裁定：入库统一为元，`unit` 列固定 `CNY`。**

顺带解决一个现存缺陷：quality 里有两处互相矛盾的换算——`compute.py:567` 按 `/1e4` 处理 `data_consensus` 的营收（那是万元），`compute.py:727` 按 `/1e8` 处理东财主营构成（那是元），而 `market_cap_yi()`（`compute.py:329-349`）干脆用"价格×股本"反推校准，在 `1 / 1e4 / 1e8` 里三选一。**同一个项目里三套假设**，靠反推兜底。

统一到元之后，这三处都可以简化成一次 `num(x)`。**并且建议在 `stock_data_fetch` 加一条探针**：单只股票最近一期 `OperatingRevenue` 必须落在 `1e7 ~ 1e13` 区间，超出就报警——这是防"某个源偷偷改用万元"的唯一自动防线。

### 12.2 `valuation` 三种口径都是 TTM/MRQ，不是静态

依据是代码里的实际字段名，不是猜的：`compute.py:419-421` 读 `PE_TTM` / `PB_MRQ` / `PS_TTM`，`:480` 与 `:501-503` 同样。

**裁定：列名写死 `pe_ttm` / `pb_mrq` / `ps_ttm`。** 见 §4.7。同时记下一个副作用：`pb_mrq` 的历史值会随新财报被上游重算，所以这张表是"可整段刷新"的，与其它历史型域不同。

### 12.3 `industry` 用上游原值，不做申万归一化

看两个工具实际怎么用这个字段：

| 位置 | 用法 |
|---|---|
| `quality/screen/compute.py:617-618` | `if any(k in industry for k in ("银行","保险","证券"))` —— 子串匹配判金融股 |
| `cycle/decide.py:53-62` | `is_financial(industry)` —— 同样是关键词匹配 |
| 其余 | 只在 HTML 里展示 |

**没有任何工具做"行业分位"或"行业间比较"**，申万标签只有 kline-screen 自己用（且不进共享库）。

**裁定：`stock.industry` 存上游原值 + `industry_src` 记录来源。** 归一化到申万的收益是 0（没人用它算东西），成本是维护映射表 + 处理版本变更（申万 2014 版 vs 2021 版），还会让"银行/银行业/货币金融服务"这类别名在归一化表缺项时反而匹配失败——**比原值更脆**。

将来真要做行业分位，另建一张映射表，不动主表。

### 12.4 `mainop` 的键是报告期，不是交易日

依据：`compute.py:692` 的 `_mainop(calls, annual)` 用 `annual[0]["date"]` 作查找键，返回 `{"period": "2025-12-31", "products": [...]}`；测试里也断言 `mainop["period"] == "2025-12-31"`。

**裁定：`snapshot.as_of` 按 domain 固定语义，`mainop` 存报告期末。** 见 §4.6。

---

## 13. 本轮因实测而改动的 DDL

| 改动 | 原因 |
|---|---|
| `finance` 从 6 个业务列扩到 12 个（每指标 累计/`_Q`/`TTM` 三列） | 上游本来就给单季与 TTM，且与差分结果一致（§4.2）；自己差分在缺期时会断 |
| `valuation` 的 `pe/pb/ps` → `pe_ttm/pb_mrq/ps_ttm` | 口径写进列名，防 V 分静默漂移（§4.7） |
| `snapshot.trade_date` → `snapshot.as_of` | 同一个列在 mainop 里是报告期（§4.6） |
| `stock.industry` 明确"不做申万归一化" | 工具只做关键词匹配（§12.3） |
| `stock` 增 `last_access_at` | GC 需要"90 天未访问"判据（§9） |

以上改动后重新建库验证：**11 表 / finance 21 列 / valuation 8 列 / snapshot 6 列，写入与查询冒烟通过**。
