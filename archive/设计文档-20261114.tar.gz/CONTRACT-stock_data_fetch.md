# `stock_data_fetch` 契约

- 日期：2026-11-14
- 状态：**草案定稿，待评审后落代码**
- 配套：`schema.sql`（DDL）、`SCHEMA-共享库.md`（表与命中判定）、`讨论纪要-共享数据层.md`（口径依据）
- 读者：改四个工具的人、写 `stock_data_fetch` 的人

> 这份文件回答四件事：**怎么调**（API）、**出错怎么办**（异常）、**谁在等谁**（节流）、**怎么验收**（测试）。
> 表结构不在这里定义（见 `SCHEMA-共享库.md`），数值口径不在这里讨论（见纪要）。
> 三者冲突时，**口径以纪要为准，表结构以 `schema.sql` 为准，行为以本文件为准**。

---

## 1. 定位与边界

`stock_data_fetch` 是共享库的**唯一写者**，也是四个工具**唯一的数据入口**。

| 它是什么 | 它不是什么 |
|---|---|
| 一个纯标准库的 Python 包（无第三方依赖） | 不是 daemon，不常驻、不自启 |
| 按需取数：你问它要一段，它保证给你或明确报错 | 不是调度器，没有 cron、没有"定时同步" |
| 唯一的 DB 写者（含 `coverage` / `watermark`） | 不是 ORM，不隐藏 SQL，不自动迁移 |
| 复权因子的计算方（只存 raw，因子现算） | 不缓存计算结果到库（除 raw 与因子源数据外） |

**三条硬边界**（越界即视为设计错误）：

1. **四个工具不写库**。除了 `ensure()` 内部的 `last_access_at`，任何工具不得执行 `INSERT/UPDATE/DELETE`。
2. **`stock_data_fetch` 不开后台线程、不注册 atexit 之外的钩子**。进程退出即停止。
3. **库版本不符时不做任何自动修复**。只报错，人来做。

---

## 2. 包结构

> 上游已不止三个（腾讯自选股 / 东方财富 / 通达信 / baostock / akshare / efinance）。
> **源怎么组织、哪个域用哪个源、谁能校验谁**，见 `SOURCES-数据源路由.md`；本章只讲文件怎么放。
> 一句话：适配器在 `upstream/`（下文改称 `sources/`），路由在 `router.py`，两者只通过 `fetch()` 契约通信。


**2026-11-14：包已从 `stockfetch` 改名为 `stock_data_fetch`，`tests/` 移进包内，`schema.sql` 移进包内。**
目录长这样（`stock-data-hub/` 从"库的目录"变成**工作区根**：文档 + 数据 + 五个项目平级）：

```
stock-data-hub/                       ← 工作区根，只放文档与数据
├── CONTRACT-stock_data_fetch.md      ← 本文件
├── SCHEMA-共享库.md   SOURCES-数据源路由.md   讨论纪要-共享数据层.md
├── shared.db   state/   .testtmp/    ← 数据与运行态，都在代码之外
├── stock_data_fetch/                 ← ① 数据层。**目录既是项目根又是包**（扁平布局）
│   ├── pyproject.toml                ← 项目根的文件放这里（扁平布局）
│   ├── __init__.py                   ~45   导出 preflight / Hub / 异常
│   ├── config.py                ~150   路径、环境变量、常量表（唯一可改数值的地方）
│   ├── errors.py                 ~95   异常树
│   ├── db.py                    ~125   连接、PRAGMA 回读校验、事务封装、版本检查
│   ├── calendar.py              ~150   交易日历、target_date()、滑动窗口
│   ├── need.py                  ~140   need 数据类 + fingerprint + need→区间换算
│   ├── coverage.py              ~430   hit / merge / holes 重算 / hole 重试 / settle
│   ├── throttle.py              ~260   令牌桶（按行数）+ 冷却闸 + flock 共享状态
│   ├── router.py                ~190   按域选源、降级、组级重试（见 SOURCES §7）
│   ├── factor.py                ~300   复权因子 + qfq + 进程内缓存        ← 第 4 步
│   ├── quarter.py                ~80   单季兜底（上游 _Q 为空时）
│   ├── api.py                   ~300   ensure / ensure_many / read
│   ├── hub.py                   ~190   Hub（运行期上下文）+ preflight() 六道闸
│   ├── doctor.py                 ~90   体检 CLI（只读）
│   ├── probe.py                 ~120   交叉校验探针（见 SOURCES §8，只读）
│   ├── schema.sql                      DDL。**放在包里**，装完才建得出库
│   ├── sources/
│   │   ├── __init__.py           ~75   SourceSpec 注册表 + AVAILABLE 过滤
│   │   ├── base.py              ~155   fetch() 契约 / Got / BatchError / Quota
│   │   ├── mcp.py               ~226   ← 搬 judge/common/mcp.py，不改协议
│   │   ├── tdx.py               ~160   kline / quote（tqFlag=0 原材料，要令牌）
│   │   ├── westock.py           ~200   finance / dividend / quote / profile / snapshot
│   │   ├── eastmoney.py         ~140   kline（fqt=0）/ valuation / finance 备 / mainop
│   │   ├── baostock.py          ~150   可选：复权因子 / 估值 / 日历（只做校验）
│   │   ├── akshare_lg.py         ~80   可选：乐咕估值（只做校验）
│   │   └── efinance.py           ~80   可选：东财第二条通道（只做吞吐，默认关）
│   └── tests/                          ← **在包内**：同版本、同一次移动、同一次发布
│       ├── __init__.py  __main__.py    `python -m stock_data_fetch.tests` 跑全部
│       ├── test_gates.py        ~215   闸门与边界
│       ├── test_coverage.py     ~470   need / coverage / verdict / 退避
│       ├── test_fetch.py        ~735   throttle / sources / router / ensure
│       └── test_factor.py       ~330   因子 / qfq / 幂等 / 缓存
├── stock_kline_screen/               ← ② 按新架构重写的四个工具（第 3 项起）
├── stock_quality_screen/
├── stock_cycle_elastic/
└── stock_judge_top/
```

**项目名、目录名、import 名、发行名，四个都是 `stock_data_fetch`，而且只有一层目录。** 2026-11-14 定：全部用下划线（不搞"连字符项目名 + 下划线包名"），并且**扁平布局**——`stock_data_fetch/` 既是项目根（`pyproject.toml` 在这），又是包（`__init__.py` 在这）。一开始做成了嵌套的 `stock_data_fetch/stock_data_fetch/`（setuptools 的标准 flat 布局），但两层同名目录每次 `cd` 都要多想一下，收益为零。扁平布局的唯一代价是 `pyproject.toml` 里要写 `package-dir = { stock_data_fetch = "." }`，把包根重映射回 `.`。**这一条对四个待重建的工具同样适用。**

四个待重建的工具一律照此：`stock_kline_screen/`（里面直接是 `__init__.py`、`pyproject.toml`、`tests/`），不留第二层。

**为什么 `tests/` 在包内**：测试与它测的代码同版本、同一次移动、同一次发布。放包外时 `pip install` 之后就找不到测试了。代价是每个测试文件多一句 `sys.path.insert` 把项目根加回来——`tests/__init__.py` 里写了原因和两种等价跑法。

**为什么 `schema.sql` 在包内**：`config.PKG / "schema.sql"`。放项目根上时，`pip install` 之后 `create_db()` 找不到 DDL，而报错会发生在很后面（库能开、表建不出来），排查成本远高于一句路径常量。

约 3200 行，其中三个开源源是可选依赖、缺失即摘除。`sources/mcp.py` 是既有代码搬运，实际新写约 2900 行。

**为什么按"域"而不是按"上游"分模块**：四个工具说的是"我要 K 线"，不是"我要通达信"。`sources/` 只负责"把上游返回变成行"，`api.py` 只负责"要不要取、取多少、写不写"，`router.py` 只负责"这次用谁"，三层之间不互相知道对方的细节。这样加源只动 `sources/` + 注册表一行，换源只动路由顺序。

### 2.1 实现进度

| 文件 | 行数 | 状态 |
|---|---|---|
| `errors.py` | 95 | ✅ 第 1 步（`SourceUnavailable` 码 9 是第 3 步加的） |
| `config.py` | 147 | ✅ 第 1 步（`BURST_ROWS` 等是第 3 步加的） |
| `calendar.py` | 150 | ✅ 第 1 步 |
| `db.py` | 125 | ✅ 第 1 步 |
| `hub.py`（`preflight` + `Hub`） | 190 | ✅ 第 1 步；`ensure`/`read` 第 3 步接通，`factor`/`adjusted` 第 4 步接通，`single_quarter` 仍占位 |
| `tests/test_gates.py` | 210 | ✅ 28 项全过（离线） |
| `need.py` | 141 | ✅ 第 2 步 |
| `coverage.py`（含 `verdict` / `settle`） | 427 | ✅ 第 2 步（`settle` 第 3 步补） |
| `tests/test_coverage.py` | 471 | ✅ 111 项全过（离线） |
| `throttle.py` | 259 | ✅ 第 3 步（令牌桶 + 冷却闸 + `flock`） |
| `router.py` | 187 | ✅ 第 3 步（选源 / 降级 / 组级重试 / 瞬断不换源） |
| `api.py`（`ensure`，仅 kline） | 302 | ✅ 第 3 步 |
| `sources/base.py` | 155 | ✅ 第 3 步 |
| `sources/mcp.py` | 226 | ✅ 第 3 步（SSE + JSON 两种返回） |
| `sources/tdx.py` | 161 | ✅ 第 3 步；**本机无令牌，注册表自动摘除** |
| `sources/eastmoney.py` | 139 | ✅ 第 3 步只做 `kline`（`fqt=0`）；`valuation`/`snapshot` 待第 5 步 |
| `sources/__init__.py` | 73 | ✅ 第 3 步（注册表） |
| `tests/test_fetch.py` | 735 | ✅ 104 项全过（含联网用例 1） |
| `factor.py` | 300 | ✅ 第 4 步（`events` / `factor` / `qfq` / `adjusted` / 缓存） |
| `tests/test_factor.py` | 332 | ✅ 32 项全过（全离线，用例 3/4/i） |
| `quarter.py` / `doctor.py` / `probe.py` / 其余适配器 | — | 第 5–6 步 |

累计 **275 项测试全绿**（28 + 111 + 104 + 32），其中 274 项离线。一条命令跑全部：

```bash
cd stock-data-hub/stock_data_fetch && python3 -m stock_data_fetch.tests
```

`Hub.factor()` / `Hub.adjusted()` 第 4 步已接通；只剩 `Hub.single_quarter()` 是**显式 `NotImplementedError` 占位**，不静默返回空——占位报错比返回空表安全。

> 第 3 步把 `kline` 主源从 tdx 换成了 **eastmoney**（tdx 端点在独立进程 401，东财 `fqt=0` 无鉴权且逐点同值）。**`fp` 没动、旧数据没作废**——依据是 §6.1 里"`kline` raw 跨源混得起"那条。详见纪要 §22.2。

---

## 3. 公开 API

只有 6 个入口，其余皆私有（下划线开头）。

```python
from stock_data_fetch import preflight, want

hub = preflight()                     # 五道闸通过后返回 Hub；失败抛异常
hub.ensure("kline", "sh600519", want.kline(bars=300, min_bars=250))
hub.ensure_many("finance", symbols, want.finance(min_points=40))
hub.read("kline", "sh600519", want.kline(bars=300))
hub.factor("sh600519", dates)         # 后复权因子，纯计算
hub.single_quarter("sh600519", "OperatingRevenue")
```

| 函数 | 语义 | 会写库 | 会打上游 |
|---|---|---|---|
| `preflight(**opts)` | 五道闸 + 开连接 | 仅首次建库 | 否 |
| `ensure(domain, symbol, need)` | 保证"区间覆盖 + 无阻塞洞 + 够点数"，否则抛 | 是 | 可能 |
| `ensure_many(domain, symbols, need)` | 批量版，收集失败不抛（见 §3.2） | 是 | 可能 |
| `read(domain, symbol, need)` | **只读**，不满足条件也只返回现状 | 否 | 否 |
| `factor(symbol, dates)` | 后复权因子序列 | 否 | 否 |
| `single_quarter(...)` | 单季值，优先上游 `_Q` | 否 | 否 |

`read()` 单独存在的理由：渲染 HTML、二次分析、调试时只想看库里的东西，不该因为参数写大了一点就去打上游 300 次。

### 3.1 `ensure` 的返回

```python
@dataclass(frozen=True)
class Range:
    domain: str
    symbol: str
    rows: list[dict]            # 按日期/期次升序；字段名 = 表列名
    n: int                      # 行数
    start: str | None
    end: str | None
    permanent_holes: list[Hole] # 已标记永久的缺口（停牌等），不影响命中
    fetched: bool               # 本次是否真的打了上游
```

`rows` 用 `list[dict]` 而不是 tuple/namedtuple：四个工具现有代码全在拼 dict（`{"date": ..., "close": ...}`），用 dict 可以直接替换、零改造摩擦。字段名保持与上游原名一致（`OperatingRevenue`，不是 `operating_revenue`），同样是为了零映射风险。

### 3.2 `ensure_many` 的失败语义

```python
@dataclass
class Batch:
    ok: dict[str, Range]
    failed: dict[str, Exception]

    def raise_if_any(self) -> None   # 有失败就抛第一个（fatal 类）
```

**`ensure_many` 自己不抛单只失败**，因为四个工具对"某一只失败"的处理不一样：cycle 跑全市场，一只失败要停；quality 跑候选池，一只失败可跳过并记入报告。把它做成"抛"就等于替调用方做了决定。

**但必须显式消费**：`Batch.failed` 非空而没调用 `raise_if_any()` 也不看 `failed`，`doctor` 会警告。每个工具在收盘汇总里必须打印失败只数。

---

## 4. `preflight()` —— 六道闸

```python
def preflight(*, allow_intraday: bool = False,
              db_path: str | None = None,
              create: bool = True) -> Hub
```

| # | 闸 | 判据 | 不过时 | 可否绕过 |
|---|---|---|---|---|
| 1 | **盘中** | 交易日 且 本地时间 ∈ `[09:15, 15:05]` | `MarketOpenError` | `allow_intraday=True`（会打 WARNING，且写 `meta` 留痕） |
| 2 | **库可用** | `STOCKHUB_DB` 或默认路径可打开；不存在且 `create=True` → 自动建库 | `HubNotReady` | 否 |
| 3 | **版本** | `PRAGMA user_version == 1` | `SchemaMismatch`，打印重建命令 | 否 |
| 4 | **PRAGMA 落实** | 回读 `journal_mode` 必须是 `wal` | `HubNotReady`（多半是网络盘/只读盘） | 否 |
| 5 | **日历** | **本地自检**：文件可读、无 >12 天断档、最后一天距今 ≤30 天（见 §4.4） | `HubNotReady`，提示更新 json | 否 |
| 6 | **空间** | 数据目录剩余 < 500MB | 只打 WARNING | 是（GC 负责） |

### 4.1 时间窗的边界要说清

- 上界取 `15:05` 而不是 `15:00`：留 5 分钟给收盘集合竞价与上游落库。
- 下界取 `09:15` 而不是 `09:30`：集合竞价期间 K 线接口会返回"当日一根半成品 bar"，比不返回更危险。
- **不特殊处理调休补班**。调休日不交易，交易日历里没有这天，闸 1 自然放行；反过来若日历没更新导致把交易日当休市，闸 1 也会放行——这个方向的错误由闸后的 `ensure` 兜住（会因缺当日 bar 而报错），不会静默出错。

### 4.2 "自动开库"的确切含义

`create=True` 时若库文件不存在：读包内 `schema.sql`，在**同一目录** `executescript` 建库，然后重新过闸 3、4。**不做任何"补表""补列"**——那不是建库，是迁移，而迁移已明确拒绝（`SCHEMA-共享数据层.md` §10.2）。

建库失败会**删掉半成品文件**：留着它下次会被当成"库已存在"，然后崩在闸 3 上，比直接报错难查得多。

### 4.4 闸 5 为什么只做本地自检

原设计是"拿 westock `data_trade_calendar` 对一遍"。实现时否掉了，原因是它会让 **preflight 依赖网络**：

- 四个工具的每次启动都要先连一次上游。上游抖动 → 工具起不来，而"起不来"和"没有数据"是两件事，用户看到的现象会误导；
- preflight 的定位是"毫秒级、离线、只判断本地状态"。一旦它开始打网络，就不再是闸门，而是取数的一环。

所以拆成两半：

| 检查 | 在哪 | 判据 |
|---|---|---|
| 文件在不在、解析得动、有没有 >12 天断档、最后一天距今是否 >30 天 | **闸 5（本地）** | 不通过 → `HubNotReady` |
| 交易日集合与 westock / baostock 是否逐日相同 | **`probe`（跨源对账）** | 不一致 → 报告 + WARNING，不阻断运行 |

`probe` 是人工/定期跑的（`SOURCES` §8），它与启动解耦。这样"日历经不起上游挂"和"日历错了要能查出来"两件事都成立。

### 4.5 `target_date` 与闸 1 共用一个常量

`config.CLOSE_GRACE` 必须恒等于 `config.MARKET_CLOSE`（都是 `15:05`），且测试里有一条断言守着这件事。

不共用的后果：闸按 15:05 放行、`target_date` 却按 15:30 才认今天，于是 15:06 跑出来的报告**悄悄少了一天的 bar**，而且没有任何报错。

### 4.3 闸 1 与"数据没落地"是两件事

闸 1 只负责"人别在盘中跑"。15:05 之后上游可能还没算完当日 bar，这属于**数据问题**，由 `ensure` 的 hole 机制处理（§6.3），不是 `preflight` 的职责。把两件事混在一起，会导致"15:06 跑就得等"这种说不清的规则。

`target_date()` 的 `close_grace` 固定为 `15:05`，与闸 1 上界一致——**这样闭市判定只有一个常量**，不会出现"闸放行了但目标日还是昨天"的错位。

---

## 5. need 对象：区间与点数分开

```python
# need.py
@dataclass(frozen=True)
class KlineNeed:
    end_date: str          # 目标交易日（由 want.kline() 从日历推出）
    bars: int = 300        # 要多少根 → 决定 start_date
    min_bars: int = 250    # 少于这个数就 InsufficientDepth

@dataclass(frozen=True)
class FinanceNeed:
    periods: int = 43
    min_points: int = 40   # 指 TTM 点数

@dataclass(frozen=True)
class ValuationNeed:
    years: int = 10
    min_weeks: int = 480

@dataclass(frozen=True)
class DividendNeed:
    since: str             # kline.start 再往前 365 天
```

**为什么必须分开**：上一版的坑是"取 20 期刚好过 `MIN_QUARTERS_REQUIRED=20`"，静默降级出一份看起来正常的报告。

- `bars` / `periods` 决定 **取多少**（区间覆盖，硬）；
- `min_bars` / `min_points` 决定 **够不够用**（阈值，由调用方声明，超了抛）。

quality 传 `min_points=20`、cycle 传 `40`、judge 传 `6`——各要各的，谁也不会被谁卡住，谁也不许偷偷降。

### 5.1 各域默认规格

| 域 | `want.*()` 默认 | 消费者及其阈值 |
|---|---|---|
| `kline` | `bars=300` | kline-screen `min_bars=71`、judge `min_bars=250` |
| `finance` | `periods=43` | cycle `min_points=40`、quality `20`、judge `6` |
| `dividend` | `since = kline.start − 365d` | judge（无阈值，见 §8.4） |
| `valuation` | `years=10` → 520 周 | quality `min_weeks=480` |
| `quote` | `target_date` | 三者都要当期 |
| `profile` / `snapshot` | 当期 | quality / cycle |

### 5.2 fingerprint（口径指纹）

| 域 | fp | 说明 |
|---|---|---|
| `kline` | `fq=raw` | 只存不复权 |
| `finance` | `type=all;fields=all` | 三表并排、全字段 |
| `valuation` | `freq=week` | 周频 |
| 其余 | `""` | 口径单一 |

`fp` **不含** `bars` / `periods`——深度是可叠加维度，由 `start_date`/`end_date`/`n` 表达。这条不能破：一旦把深度写进 fp，`ensure(300)` 和 `ensure(71)` 会各存一份覆盖记录，同一只股票取两次。

---

## 6. `ensure()` 流程

```
1  fp  = fingerprint(domain)
2  if domain in NEED_SRC_RESET:                 ← valuation / finance 才检查（SOURCES §4.1）
3     if meta["domain_src:<domain>"] != router.pick(domain).upstream:
4        取整段（hit 视为全失效），完成后写回 meta
5  cov = read_coverage(domain, symbol, fp)
6  if hit(cov, need): touch(access) → return read()
7  flock(domain:symbol)                        ← 分片锁，不是全局锁
8    cov = read_coverage(...)                  ← 双检：等锁期间别人可能已填好
9    if hit(cov, need): return read()
10   清掉"到期可重试"的 hole 重试标记          ← §6.3
11   miss = missing_of(cov, need)              ← 要补的区间（可能多段）
12   for seg in miss:
13     throttle.take(src, expect_rows(seg))     ← 令牌桶，按行数计（§7.1）
14     got = fetch(src, domain, symbol, seg)
15     if got.error_groups:                     ← 上游自报的组级失败（§7.3）
16       throttle.penalize(src)                 ← 冷却，**不立刻重取**
17       got = retry_groups(src, got, rounds=3) ← 只重取失败的那几组
18       if got.still_failed: mark_partial(那些 symbol); raise PartialData
19     if not got.rows: raise EmptyResult       ← 空表一律当错，不是"没数据"
20     tx(): write_rows(got); merge_coverage(got); upsert_watermark(got)
21   cov = read_coverage(...)
22   if not hit(cov, need): raise InsufficientDepth / HoleUnreachable
23   return read()
```

**单线程执行**（2026-11-14 定）：整个流程没有并发、没有线程池，`ensure_many` 就是一个 for 循环。节流器仍是唯一的跨进程串行点，但进程内是顺序的——"谁在等谁"始终保持一条线，出问题能靠一行日志还原。理由见 `SOURCES` §6。

### 6.1 命中判定（相对 `SCHEMA` §5 有两处收紧）

```
hit(cov, need) :=
      cov 存在
  AND cov.fp == fingerprint(domain)
  AND cov.partial == 0
  AND cov.end_date   >= need.end
  AND blocking_holes(cov) == 0          ← 差异 1，见 §17
  AND cov.n >= need.min_*               ← 差异 2：深度只由点数表达
  ── 且仅当 domain == "dividend" ──
  AND cov.start_date <= need.start      ← 唯一看 start 的域
```

**差异 2（`start` 不参与命中）是第 2 步实现时定下的**。理由是次新股：一只 2025 年上市的票永远凑不满
"回溯 300 根"，按 `start` 判会让它每次运行都去重取一次、永远不命中，把配额全烧在一只票上。
"够不够用"本来就是这个意思——`start` 只是**取数范围**的起点，`min_*` 才是深度门槛。

`dividend` 例外：它的 `start` 语义不是"取数范围"而是"我们查过那么早没有"，
十年不分红是合法状态（0 行也算查到），所以必须判 `start`。

### 6.2 `merge_coverage` 只重算、不增量

```
new.n     = SELECT COUNT(*)                     ← 不累加，重数
new.start / new.end:                            ← 按域分两种（第 2 步修正，见 §17）
    dividend : start = min(数据最早, need.start, old.start)   ← “查过的区间”
               end   = max(数据最晚, old.end)
    其余域    : start = 数据最早, end = 数据最晚              ← 区间就是数据本身的范围
new.holes = recount(calendar, new.start, new.end) ← 重算，不增量
```

`n` 和 `holes` 一律重算。增量累加在"重取同一段"时会算成两倍，而这个错误不会立刻暴露——它只在三个月后表现为"明明够 300 根却报不够"。

`start`/`end` 不能一律取 `min/max`：K 线是滚动删除的，保留旧边界会让 GC 之后重算出一个"老数据被删了"的假缺口。

### 6.3 hole 重试状态机（你选定的退避方案）

`coverage.hole_detail` 存 JSON 数组（**纯数据扩展，不改 DDL、不升 `user_version`**）：

```json
[{"from":"2026-03-02","to":"2026-03-05","n":4,
  "retry":2,"next_try_at":"2026-11-14T18:00:00","cls":"retry","reason":"no_data"}]
```

| 字段 | 含义 |
|---|---|
| `from` / `to` | 连续缺口的首尾（连续段算一个） |
| `n` | 段内交易日数 |
| `retry` | 已重试次数 |
| `next_try_at` | 下次允许重试的时刻；未到点则**视为阻塞**（不许绕过） |
| `cls` | `retry`（还会重试）/ `permanent`（不再自动重试） |
| `reason` | `no_data` / `upstream_skip` / `suspended` |

退避序列：`retry 1→+1h`、`2→+6h`、`3→+24h`、`4→+72h`、`5→+168h`、`≥6→permanent`。

**要点**：`permanent` 不是"假装没有洞"，而是"承认它是永久缺口，不再为它反复打上游"。它仍然：

- 计入 `holes`；
- 出现在 `Range.permanent_holes` 和 `doctor` 报告里；
- **不阻塞命中**（否则停牌股永远无法命中，每次跑都去问上游一次，白等 168 小时）。

这就是 §6.1 里 `blocking_holes` 的含义：只统计 `cls != permanent` 的洞。`force=True` 时清空所有重试标记重来一次。

### 6.4 `force=True` 的用途

只给两个场景：

1. `valuation` 季度强制刷新（`pb_mrq` 会被上游重算，`SCHEMA` §4.7）；
2. `doctor --force-refetch SYMBOL`（人工排查）。

除此之外禁止使用。用它来"解决 depth 不够"是错的——深度是上游上限，重取一百次也一样。

---

## 7. 节流器：配额 + 反馈，不是固定间隔

**这一章在 2026-11-14 实测后整体重写过**（纪要 §18.2 有完整数据）。原设计是"每个 src 一个固定最小间隔"，实测证明它不可靠：

| 批间间隔 | 10 批 × 60 只的完整批数 |
|---|---|
| 0.6s | 5/10 |
| 1.0s | 8/10 |
| 1.6s | 7/10（前 7 批完整，之后 60→30→20→10） |
| 3.0s | 3/4 |

**非单调**——间隔大的反而更差。换成"行数"视角就一致了：不管你切多大批、间隔多久，大约消耗 **2.5–3 万行**之后配额耗尽，之后逐批恶化。所以节流对象是**返回行数**，不是请求次数，也不该用固定睡眠近似。

### 7.1 令牌桶（按返回行数计）

```python
throttle.take(src: str, rows: int, budget: float = 300.0) -> None
```

| 参数 | 默认 | 依据 |
|---|---|---|
| `RATE` | 15000 行/分钟 | 实测下限 20–30k 的 60%，留余量 |
| `BURST` | 12000 行 | 一批 60 只 × 200 根 = 12000，得一次拿满 |
| `budget` | 300s | 累计等待上限，超了抛 `ThrottleTimeout` |

`expect_rows(seg)` 由 need 估算：`kline` = `bars × 1`（单只）、批量时 `bars × len(codes)`；`finance` = `periods × 3 表`。**估多了只是慢一点，估少了会打穿上游**，所以宁多勿少。

跨进程共享：桶状态放 `state/<src>/bucket.json`（`{tokens, ts}`），`flock` 保护整个"读-算-睡-写"过程，与旧设计的"持锁睡"同一套机制——**先放锁再睡会让两个进程同时醒来，桶立刻被透支**。

### 7.2 冷却闸（限频反馈）

固定间隔治不了配额耗尽，唯一可靠的信号是**上游自己报的限频**：

```
fetch 返回 metadata.errorCount > 0  →  throttle.penalize(src)
```

| 状态 | 取值 |
|---|---|
| 首次冷却 | 30s（实测 6s 就能恢复，但持续请求会立刻再触发，故取 30s） |
| 连续触发 | ×2 递增，上限 300s |
| 一次干净返回 | 减半 |
| 连续 3 次干净 | 清零 |

冷却期内 `take()` 直接睡到冷却结束（这是预期内的等待，不抛异常）；只有累计等待超 `budget` 才抛 `ThrottleTimeout`。

**冷却 ≠ 不可用**（第 3 步实机踩出来的，纪要 §22.4③）：路由排序时冷却中的源**排到后面**，不是摘掉；如果一个都不剩就干等。第一版写成"冷却中→跳过"，结果主源一进 300s 冷却，整批 20 只股票集体报"没有可用源"——故障面从"变慢"扩大成"全部失败"。

**瞬断也按限频处理**（第 3 步新增）：`RemoteDisconnected` / 超时 / 5xx 这类 `transient` 错误**不换源**，而是冷却 + 重试同一源，连断 3 次才抛 `ThrottleTimeout`（码 6）。换源等于把压力转给另一家、同时把数据换成另一家的口径，而"掐连接"恰恰是限频最常见的形式（东财就不用 429 而用掐 TCP，纪要 §22.5）。

### 7.3 组级重试：只重取失败的那 10 只

上游把一次请求**内部按 10 只一组**拆开独立判定，失败组在 `errors[]` 里自报（`symbol` 字段是逗号串，正好 10 只）：

```json
"metadata": {"total": 119, "successCount": 110, "errorCount": 9},
"errors": [{"symbol": "sh600179,sh600182,...,sh600192",
            "code": "BATCH_ERROR",
            "message": "查询dayK线异常：error_type=2 suggest=2 msg=服务限频"}]
```

所以 **`partial` 的判据是 `errorCount > 0` 或 `successCount < total`**，不是"请求清单减返回清单"——后者只能告诉你少了谁，不能告诉你"为什么少"，而这两者要采取的动作完全不同（限频要退避，退市要记永久洞）。

重试规则：

| 规则 | 做法 | 理由 |
|---|---|---|
| 只重失败组 | 按 `errors[].symbol` 拆回去重取 | 重取整批等于把配额再花一次 |
| 重试前必须 `penalize` | 先冷却再取 | **kline-screen 现在是"丢码就拆半立刻重取"，实测这会让限频加重**（连发 6 批全败） |
| 最多 3 轮 | 3 轮后仍失败 → 对这些 symbol 记 `partial=1` | 不无限重试 |
| 记 `partial` 的粒度是 symbol | 失败的 10 只各自 `partial=1`，成功的正常推进 `end_date` | 整批 `partial` 会让已经拿到的数据白等下一次 |

### 7.4 空表一律当错误

实测踩到：`data_kline` 传错参数名（写成 `codes` 而不是逗号 `code`）**不报错**，会把 `["sh600519"]` 拼成 `[sh600519`，返回 `{"nodes": []}`；`data_finance` 同样。

空表有两种含义——"参数写错"和"这只股票真没数据"——必须分开：

- `need.start` 在 `list_date` 之前、或整段停牌 → 合法空，记 `permanent` 洞；
- 其余一律 `EmptyResult`，**不允许静默写 0 行**。

### 7.5 各 src 的差异

| `src` | 批量能力 | 节流方式 |
|---|---|---|
| `eastmoney` `push2his`（**kline raw 主源**） | **无批量**，单 `secid`；但一次给全历史（`beg=1990`） | 令牌桶（15k 行/分钟）+ 冷却闸；**实测"连取 20 只后掐 TCP"**，见下 |
| `westock`（kline/finance/quote） | 逗号 `code`，**≤150 只/次实测完整**，200 只开始掉组 | 令牌桶 + 冷却闸 + 组级重试 |
| `eastmoney`（snapshot 类） | 单次最多 500 只（NL 查询） | 同上 |
| `tdx`（kline raw 备源） | **无批量**，单 `code` | 300ms 最小间隔 + 冷却闸；**⚠️ 独立进程无令牌，注册表摘除** |

> 本表只列**主源**。完整的六源清单（含 baostock / akshare / efinance 三个开源源）、域×源矩阵、跨上游校验规则，见 `SOURCES-数据源路由.md`。

`tdx` 没有批量能力，直接决定了 `ensure_many("kline")` 只能是"逐只循环"——300 只 = 300 次请求。**这一点没有因为换成东财而改变**（东财这个接口也没有批量），只有单只成本从 300ms 最小间隔变成实测 0.42s。

**东财的限频形态必须单独记住**（纪要 §22.5）：用完突发配额后它**不返回 429，直接掐 TCP**（`http.client.RemoteDisconnected`）。`RemoteDisconnected` 是 `OSError` 子类而**不是** `URLError`，只接 `URLError` 会让它裸穿到四个工具。适配器统一转成 `SourceUnavailable(transient=True)`，router 按限频处理（冷却 + 重试同源）。

实测还否掉了"调大间隔就能跑全市场"：间隔拉到 1.0s / 1.5s **照样全断**，静默几十秒后恢复——是**突发配额**，不是速率滑窗、不是 IP 封禁。

配置项 `STOCKHUB_RATE_<SRC>`（行/分钟）、`STOCKHUB_MIN_INTERVAL_TDX_MS`、`STOCKHUB_BURST_ROWS` 可覆盖，便于校准而不改代码。

**为什么串行点是节流器而不是数据库**：数据库要的是"不冲突"（WAL + `busy_timeout=5000` 就够，实测 0 失败；不设则七成批次 `database is locked`），节流器要的是"全局唯一配额"。用数据库做节流会把 fsync 卷进热路径，而且挡不住"两个进程各自持有不同行锁"的情况。

---

## 8. `factor()` —— 复权因子

```python
factor(symbol: str, dates: list[str]) -> list[float]     # 与 dates 一一对应
```

```
r_d       = P_prev / P_ref(d)
P_ref(d)  = (P_prev − cash + rights × rights_price) / (1 + bonus + transfer)
factor(t) = Π_{d ∈ (kline.start, t]} r_d
qfq(t)    = raw(t) × factor(t) / factor(T)        # 由调用方算，或 stock_data_fetch 提供 helper
```

### 8.1 累乘区间为什么从 `kline.start` 开始就够

前复权是比值 `factor(t)/factor(T)`。**起点之前的所有除权日，在分子分母里同时出现，严格抵消**。所以只需要窗口内的除权日，由此带来两个好处：

- 不需要为了"算最早那根 bar 的因子"多取一根 K 线（`P_prev` 一定落在窗口内）；
- K 线窗口向前滚动、旧除权日掉出窗口时，**剩余 bar 的 qfq 数值不变**（比值不变）——这保证了"同一根 bar 今天和三个月后的前复权价一致"，不会出现历史数值自己漂移。

`dividend` 的 need 仍然按 `kline.start − 365d` 取，那是为了**审计与将来要算后复权（hfq）**，不是因为算 qfq 非要它。

### 8.2 四条守卫

| 守卫 | 做法 | 不这么做的后果 |
|---|---|---|
| 每 10 股 → 每股 | 入库即 `÷10`（`dividend.*_per_share` 已是每股，这里只校验量级） | 除数 3.0 变 21，已踩过 |
| 除权日非交易日 | 取 `ex_date` 及之前最后一个交易日作为 `d` | 撞假期时因子整段错位 |
| `bonus/transfer/cash` 全为 0 | `r_d = 1`，跳过 | 无 |
| `P_ref <= 0` 或 `cash >= P_prev` | 抛 `FactorError`，**不允许跳过** | 跳过会让 qfq 静默偏高，且看不出来 |

### 8.3 缓存

进程内 `dict[symbol] → (签名, events)`，`events` 是 `(ex_date, day, r, ...)` 的元组。**不做跨进程缓存**——同一个库被四个工具读，缓存一致性成本得不偿失，而重算是毫秒级。

签名 = `(dividend 的 (行数, max(updated_at)), kline 的 (行数, min(date), max(date)))`。

**为什么必须带 kline 的边界**（原设计只盯 `dividend`，第 4 步实现时发现不够）：`P_prev` 是从 `kline` 查出来的。只盯分红的话，"补了一批更早的 K 线"之后，原先因为落在窗口外而被跳过的除权日应该被纳入，但缓存不会失效——**因子会一直少乘那几个 `r`，而且一点报错都没有**。`tests/test_factor.py` 第 5 组有一条专门钉这个场景的断言。

**缓存的是"事件表"而不是"因子列表"**：事件与调用方传什么 `dates` 无关，锚点无关。缓存因子列表则每次换一批日期就得重算，等于没缓存。

### 8.4 `dividend` 没有 `min_points`

分红数量天然不定（有的股票十年一次都没有）。**"没有分红"是合法状态，`factor ≡ 1.0` 也是合法结果**，不能当成数据缺失。所以 `DividendNeed` 只校验 `start_date <= since` 与 `holes == 0`。

### 8.5 落地形态（第 4 步实现，2026-11-14）

```python
events(conn, cal, symbol, *, use_cache=True) -> tuple[Event, ...]   # 除权事件表
factor(conn, cal, symbol, dates, *, use_cache=True) -> list[float]  # 与 dates 一一对应
qfq(rows, factors, anchor_factor, *, cols=PRICE_COLS) -> list[dict] # 纯函数，缩放
adjusted(conn, cal, symbol, rows, *, anchor=None) -> list[dict]     # 便捷：算+缩放
clear_cache(symbol=None) -> None
```

三条实现口径，都值得记一笔：

1. **窗口外的除权日跳过，窗口内的缺口报错。** 二者在代码里只差一个 `day < first_bar` 判断，但后果天差地别：前者合法（分子分母抵消，§8.1），后者是数据缺口——跳过会让 qfq **整段偏高且看不出来**，所以抛 `InsufficientDepth`。
2. **锚点默认值在两个入口不一样。** `factor.adjusted()` 默认锚在最后一根 bar（**同样的输入必须得到同样的输出**，否则测试没法离线断言）；`Hub.adjusted()` 默认锚在 `self.target`（工具要的是"和今天可比"的价格）。两者只在"最后一根 bar 之后又发生过分红"时才有差别——而那正是最容易忘的情形，所以 Hub 这一层刻意选了 target。
3. **`PRICE_COLS` 只缩放 open/high/low/close，不动 volume/amount。** 量在除权日不会因为送股而"变小"，而且换手率要用**未复权量配未复权价**才对得上。这两个域从一开始就是分开看的。

---

## 9. `single_quarter()` —— 只在兜底时用

```python
single_quarter(symbol, field) -> Series       # Series(values, source, missing)
```

优先级：

1. 库里有 `field + "_Q"` 非空 → `source="upstream"`（43 期全有，正常路径）；
2. 该期为 Q1 → `source="q1"`，值 = 累计；
3. 上一期存在且连续 → `source="derived"`，值 = 累计差；
4. 上一期缺失 → `None`，记入 `missing`，**不填 0**。

第 4 条是重点。填 0 会让下游的"同比""环比"算出一个看起来合理的数，而那个数是假的。`missing` 非空时调用方必须自己决定是中止还是标记。

---

## 10. 异常树与工具动作

```
StockfetchError
├── MarketOpenError           盘中
├── HubNotReady               库打不开 / PRAGMA 没落实
├── SchemaMismatch            版本不符
├── InsufficientDepth         拿不到那么深
├── PartialData               限频截断（组级重试 3 轮后仍失败）
├── EmptyResult               上游返回空表（多半是参数写错）
├── HoleUnreachable           只含 permanent 洞但 n < min_*
├── ThrottleTimeout           等节流/冷却超时
└── FactorError               复权数据自相矛盾
```

| 异常 | 触发条件 | 工具动作 | 建议文案 |
|---|---|---|---|
| `MarketOpenError` | 交易日 09:15–15:05 | **立即退出**，码 2 | `现在是交易时段（09:15–15:05），K 线是不完整的。请在收盘后运行。` |
| `HubNotReady` | 库不存在且无法建 / PRAGMA 不是 wal | **立即退出**，码 3 | `共享库不可用：<原因>。若在网络盘上，请把库放到本地磁盘。` |
| `SchemaMismatch` | `user_version != 1` | **立即退出**，码 3 | `库版本 <cur>，需要 <EXPECTED>。数据可再生，请删库重建：rm <path> 后重跑。` |
| `InsufficientDepth` | 覆盖够但 `n < min_*` | **立即退出**，码 4 | `sh600519 的 finance 只有 20 期，需要 40 期。上游只提供 43 期，请检查该股是否次新股。` |
| `PartialData` | 限频组级重试 3 轮仍缺 | **退出**，码 5（不再重试，重试交给下次运行） | `上游限频，sh600519 等 10 只在 3 轮重试后仍缺。库已保留已取到的部分，下次运行会继续补齐。` |
| `EmptyResult` | 上游返回空表且不属于"次新/停牌" | **立即退出**，码 5 | `上游对 sh600519 返回空表。这通常意味着参数或接口变更，请用 STOCKHUB_LOG=DEBUG 复查请求参数。` |
| `HoleUnreachable` | 永久洞导致点数不足 | 可**逐股跳过**并写入报告 | `sh600519 在 2026-03-02..03-05 无数据（已重试 6 次）。` |
| `ThrottleTimeout` | 累计等待 > 300s | **立即退出**，码 6 | `已等待上游配额 300 秒仍未恢复。可能是另一个进程正在大量取数，请稍后重跑。` |
| `FactorError` | `P_ref <= 0` 等 | **立即退出**，码 7 | `sh600519 在 2026-06-11 的除权数据自相矛盾（P_ref=…）。请检查 dividend 表。` |

**唯一允许"逐股跳过"的是 `HoleUnreachable`。** 其余一律终止进程。理由：这条边界一旦放宽，工具就会开始出"缺了几只股但看起来正常"的报告，而那种报告比崩溃坏得多——崩溃会被重跑，错误报告会被拿去用。

---

## 11. `read()` 的数据形态

不做 ORM、不做 DataFrame 依赖，直接给"能喂给现有代码"的形状。

```python
# kline
{"dates": [...], "open": [...], "high": [...], "low": [...],
 "close": [...], "volume": [...], "amount": [...]}

# finance：一行一期，键 = 表列名（与上游同名）
[{"period": "2026-09-30", "OperatingRevenue": 1.3097e11, ...}, ...]

# valuation
{"dates": [...], "pe_ttm": [...], "pb_mrq": [...], "ps_ttm": [...], "total_mv": [...], "circ_mv": [...]}
```

`kline` 给"列式"、`finance` 给"行式"，是刻意的：K 线永远整列用（画图、算均线），财报永远逐期遍历（算 TTM、做分位）。

---

## 12. 配置

| 环境变量 | 默认 | 说明 |
|---|---|---|
| `STOCKHUB_DB` | `~/MyData/stock-data-hub/shared.db` | 库路径 |
| `STOCKHUB_STATE` | `~/MyData/stock-data-hub/state/` | lock / 令牌桶 / 冷却状态 / 备份 |
| `STOCKHUB_CALENDAR` | `<kline-screen>/database/trading_calendar.json` | 交易日历，13KB，不进库 |
| `STOCKHUB_RATE_<SRC>` | `westock=15000` 行/分钟，`eastmoney=15000`，`tdx=∞` | 令牌桶速率（§7.1） |
| `STOCKHUB_MIN_INTERVAL_TDX_MS` | `300` | tdx 无批量也无实测限频，只留最小间隔 |
| `STOCKHUB_COOLDOWN_BASE` | `30`（秒） | 限频后首次冷却，连续触发翻倍到 300s |
| `STOCKHUB_ALLOW_INTRADAY` | 未设 | 设 `1` 等价于 `allow_intraday=True`，打 WARNING |
| `STOCKHUB_LOG` | `INFO` | `DEBUG` 时打印每次上游请求的参数 |

**交易日历用 kline-screen 那份、不进库**，理由见 `SCHEMA` §4.4：日历是"规则"不是"数据"，进库就要维护更新，反而多一个失效点。默认路径写死一个相对位置，并由 `preflight` 校验"文件可读 + 覆盖到今年"，不满足就 `HubNotReady`。

---

## 13. 日志与体检

每次 `ensure` 打一行（`INFO`），字段固定，便于 `grep`：

```
ensure kline sh600519 need=2026-11-13/300 hit=0 fetch=301ms rows=300 holes=0 quota=11800 cool=0 fetched=1
```

- `quota` = 本次调用后令牌桶剩余行数预算；`cool` = 冷却剩余秒数（0 表示正常）。
- 触发限频时额外打一行 `WARN`：`throttle penalize westock errorCount=9 -> cooldown 30s`。

`python -m stock_data_fetch doctor`（**只读**，一个字节都不写）输出：

| 段 | 内容 |
|---|---|
| 库 | 路径、体积、`user_version`、`journal_mode`、各表行数 |
| 覆盖 | 每域每口径：股票数、`start/end` 分布、`n` 的中位数 |
| 异常 | `partial=1` 的记录、`holes>0` 的股票及 `hole_detail`、`permanent` 清单 |
| 空间 | 各表字节数、可回收空间（`PRAGMA freelist_count`） |
| 新鲜度 | 各域 `end_date` 距今的交易日数（>5 打 WARNING） |

---

## 14. 四个工具怎么接

改造原则：**先替换数据来源，不改计算逻辑**，改完逐值比对，再谈别的。

| 工具 | 现在 | 接法 |
|---|---|---|
| **kline-screen** | westock 批量全市场 → `database/*.json` | K 线写库通道换 tdx + `ensure_many("kline", ...)`；`min_bars=71` |
| **quality-screen** | westock `finance`/`quote`/`profile` | 这三个改读库；估值/主营/一致预期/评级 5 个独占域仍自取，但写库 |
| **judge-top** | kline qfq + `finance num=60` + 3 段循环 | 读 raw + `hub.factor()`；finance `min_points=6`；`CACHE_VERSION` 3→4；`FIN_NUM` 60→6 |
| **cycle-elastic** | westock `finance num=44` | 读 43 期，`min_points=40`（**唯一传 40 的工具**） |

每个工具的 `main()`/`run()` 入口固定三行：

```python
hub = preflight()                       # 闸在这里，不允许在别处再判盘中
hub.ensure_many("kline", universe, want.kline(bars=300, min_bars=71))
...                                     # 后续全部改读 hub.read(...)
```

**`preflight` 只调一次**，放在入口。子模块里再调会导致重复开库、重复建库竞争，而且容易有人传 `allow_intraday=True` 把闸绕了。

改造边界的例子（judge-top 的 `_fetch_kline`，现在是 3 段 × 300 + 整年空洞检测）：

```python
# 改前：~45 行，含分页、拼接、空洞检测、复权
# 改后：
r = hub.ensure("kline", symbol, want.kline(bars=300, min_bars=250))
f = hub.factor(symbol, r.rows_dates)
qfq = [c * fi / f[-1] for c, fi in zip(r.close, f)]
```

---

## 15. 验收测试（8 条）

文件在 `stock_data_fetch/tests/`，按步拆成四个：`test_gates.py`（用例 8 与六道闸）、`test_coverage.py`（用例 5 与补充 h）、`test_fetch.py`（用例 1/2/7/k）、`test_factor.py`（用例 3/4/i）。标 **[N]** 的不打上游，可离线跑；标 **[U]** 的需联网。

**用例 3/4 这里做成了离线版本**：用 2026-11-14 记录下来的两组真实价格（格力 41.58→39.58、比亚迪 337.00→111.42）做算术自洽验证，不需要联网打 tdx。真正打上游的只有用例 1，且它是手动开关（`STOCKHUB_LIVE=1`）。

| # | 用例 | 断言 | 网 |
|---|---|---|---|
| 1 | 空库 `ensure("kline", sh600519, 300)` | `n == 300`，`coverage.holes == 0`，`fp == "fq=raw"` | U |
| 2 | 紧接着再调一次 | 上游调用计数 **== 0** | N |
| 3 | 格力除权日前后 qfq | `abs(qfq[bef] − qfq[aft]) < 0.01`（41.58−2.00 与 39.58 同值） | U |
| 4 | 比亚迪送转 | 自算 qfq vs tdx 前复权，逐点误差 `== 0.00`（除数 3.0） | U |
| 5 | 人为删掉中间一天 → `ensure` | 抛 `InsufficientDepth`，**不返回 299 根** | N |
| 6 | 上游只回一半（patch fetch 返回 partial） | 抛 `PartialData`，且 `coverage.end_date` **未推进** | N |
| 7 | 两进程同时 `ensure` 同一只（multiprocessing） | 上游调用计数 **== 1**，两边都拿到 300 根 | N |
| 8 | `PRAGMA user_version = 2` 后 `preflight()` | 抛 `SchemaMismatch`，且库内**任何表行数不变** | N |

补充 4 条（不编号，跑在 [U] 批次里）：

- **h**：`holes` 重试状态机——把 `next_try_at` 设到未来，`ensure` 必须视为阻塞；设为过去则重试一次且 `retry += 1`；
- **i**：`factor` 幂等——K 线窗口向前滚动一天后，重叠区间内的 `qfq` 逐点不变（§8.1 的推论，这是最容易写错的地方）；
- **j**：`doctor` 跑完 `sha256(库文件)` 不变（证明"只读"）；
- **k**：限频路径——mock 一个 `errorCount=9 / errors[]` 的响应，断言：① 只对失败的那 10 只重取（请求里的 code 清单就是 `errors[].symbol`）；② 重试前 `throttle.penalize` 被调用过；③ 3 轮后失败的 symbol 各自 `partial=1`，而成功的那部分 `end_date` 已推进。

用例 6 的断言也据此收紧：**partial 的判据是 `metadata.errorCount > 0`，不是"返回条数 < 请求条数"**——后者无法区分"限频"与"退市"。

---

## 16. 实现顺序

| 步 | 内容 | 可独立验证 | 状态 |
|---|---|---|---|
| 1 | `errors.py` + `config.py` + `db.py`（含闸 3/4）+ `calendar.py` + `hub.py`（六道闸） | 用例 8 | ✅ 28 项 |
| 2 | `need.py` + `coverage.py`（`hit`/`merge`/`recount_holes`/`missing_segments`/`verdict`） | 用例 5、补充用例 h | ✅ 111 项 |
| 3 | `throttle.py`（令牌桶 + 冷却闸）+ `sources/base.py` + `sources/mcp.py` + `sources/eastmoney.py` + `sources/tdx.py` + `router.py` + `api.ensure`（只做 kline） | 用例 1/2/7/k | ✅ 104 项（含联网用例 1） |
| 4 | `factor.py` | 用例 3/4/i | ✅ 32 项（全离线） |
| 5 | `sources/westock.py`（finance/quote）+ `sources/eastmoney.py`（valuation/snapshot）+ `quarter.py` | 用例 6 | — |
| 6 | `doctor.py` + 用例 j + 三个工具的接入改造 | — | — |

第 3 步已跑通"judge-top 读 K 线"这一条最长的链路，第 4 步把"K 线 → 复权价"补齐，剩下的都是加域与接入。**第 5–6 步动代码前仍会先给说明**（纪要 §11 第 6、7 项）。

> **第 3 步变更了一处源排位**：`kline` 主源从 tdx 改为 **eastmoney**。原因不是"东财更好"，是 tdx 的 MCP 端点要 OAuth Bearer 而独立 CLI 进程拿不到（`401 Missing Bearer authorization`），东财 `fqt=0` 无鉴权且与 tdx **逐点同值**。因为 §6.1 早已判定 `kline` raw 跨源混得起，**这次换源没动 `fp`、没作废旧数据**。详见纪要 §22.2、`SOURCES` 脚注 ⁶⁷。
>
> 第 3 步的行数比预估多 40% 左右（`api.py` 302 + `throttle.py` 259，预估合计约 400）。多的是"冷却中的源要排到后面而不是摘掉"、`settle()`、"瞬断按限频处理"这三处——**都是先跑出故障、再补的边界分支**，预估里没有。

第 1–2 步实际落地比预估多 200 行左右（`coverage.py` 393 vs 预估 200）。多出来的主要是 `verdict()`、`missing_segments()` 的三段拼接与 `Hole` 的 JSON 往返——**预估的行数里没有"边界条件各写一句解释"的成本**，后面几步按 1.3 倍估。

---

## 17. 与本套其它文档的差异（读旧文档时注意）

| 位置 | 旧说法 | 本文件 |
|---|---|---|
| `SCHEMA` §5 命中判定 | `holes == 0` 才命中 | 改为 `blocking_holes == 0`（`permanent` 洞不阻塞，但计入报告）。原因：停牌股的洞永远不会消失，按旧判据 → 永远不命中 → 每次跑都白打一次上游并等 168 小时 |
| `SCHEMA` §8 `dividend` need | `since = kline 起点 − 1 年`，理由写的是"否则因子少乘一次" | 该理由不成立：窗口外的除权在 `factor(t)/factor(T)` 里抵消（§8.1）。区间照旧保留，但目的改为审计与将来算 hfq |
| `schema.sql` 第 197 行 `hole_detail` 注释 | 示例为 `[["2026-03-02","2026-03-05"]]` | 实际形态为对象数组（§6.3），需重试计数才能实现退避。**纯注释修正，DDL 不变、`user_version` 仍为 1** |
| `SCHEMA` §6 `ensure` 流程 | 无 hole 重试、无 `force` | 补 §6.3 状态机与 §6.4 用途 |
| **本文件 §7（旧版）** | "每个 src 一个固定最小间隔（westock 1600ms / tdx 300ms），持锁睡" | ❌ 已被 §18.2 实测推翻：间隔与成功率**非单调**（0.5s 能过、1.0s 反而失败）。改为按返回行数的令牌桶 + 限频反馈冷却（§7.1–7.2） |
| **kline-screen `_kline_fetch`** | "丢码就当场把缺失的拆半再取" | 实测证明这会**加重**限频（连发 6 批全败）。改为"先 `penalize` 冷却，再只重取 `errors[].symbol` 那几组"（§7.3）。改造 kline-screen 时必须一起改 |
| `SCHEMA` §3.1 写者表 | `finance` 写入者标"东财" | 三表实际来自 **westock `data_finance`**（逗号 `code`，返回 `{data:{symbol:{balance,income,cashflow}}}`）；东财负责 snapshot 类（mainop/consensus/rating）与 `valuation`。只是标注错，不影响 DDL |
| **源清单** | 本文件按三源（westock / eastmoney / tdx）写 | 已扩到六源，且区分「上游」与「传输」：`fp.src` 记**上游**不记传输；同上游不同传输（efinance vs 东财直连）**不能互相校验**。见 `SOURCES-数据源路由.md` |
| **§6.2 `merge` 只增不减** | `new.start = min(old.start, got.start)`，对所有域一律保留旧边界 | 改为**按域分两种**（第 2 步实现时发现，见下）：`dividend` 的 `start` 记"我们查过的最早一天"，取 `min(数据最早, need.start, 旧 start)`；`kline`/`finance`/`valuation` 的区间**就是库里数据本身的范围**，不保留旧边界 |
| **§10 异常表的触发条件** | 只写了每个异常各自的语义，没写"多个条件同时成立时抛哪个" | 补 `coverage.verdict()` 作为唯一判定出口，顺序：`partial → PartialData`；有阻塞洞 `→ InsufficientDepth`；只剩 permanent 洞且点数不够 `→ HoleUnreachable`；其余 `→ InsufficientDepth`。**有了这个顺序，用例 5 才能离线断言** |
| **§7.5 源排位（第 3 步前）** | `tdx` 是 `kline` 主源 | 改为 **eastmoney 主 / tdx 备**。tdx 端点要 OAuth Bearer，独立 CLI 进程 401；东财 `fqt=0` 无鉴权且与 tdx **逐点同值**。`fp` 不变、旧数据不作废（§6.1 早已判定 `kline` raw 跨源混得起） |
| **`router.pick` → `router.order`（第 3 步）** | "主源冷却中 → 跳过，取下一个" | 改为"**冷却中的排到后面，全都冷却就等**"。按旧写法，主源一进 300s 冷却整批股票集体报"没有可用源"，故障面从"变慢"扩大成"全部失败" |
| **§10 异常树（第 3 步）** | 无"源不可达"这一类 | 新增 `SourceUnavailable`（码 9）。缺令牌 / 鉴权失败 / 接口变更 / 连续空表都归它；带 `transient=True` 的实例由 router 当限频处理（冷却 + 重试同源），**不降级** |
| **`coverage` 新增 `settle()`** | 空表一律记洞、按 1/6/24/72/168h 退避 | 停牌股会白烧 6 次重试。改为"同一次运行里同一段取两次仍空 → 认账判 `permanent`"。**"真没有"与"这次没取到"在返回值上无法区分，唯一办法是再问一次** |
| **§8.3 缓存签名（第 4 步）** | 只盯 `dividend` 的行数与 `updated_at` | 必须**带上 kline 的 `(行数, min, max)`**。`P_prev` 从 kline 查，只盯分红的话"补了一批更早的 K 线"之后缓存不失效，因子会永远少乘那几个 `r`，且没有任何报错 |
| **§8 窗口外除权（第 4 步）** | 未区分"窗口外"与"窗口内缺口" | 两者在代码里只差一个 `day < first_bar` 判断：**窗口外跳过**（分子分母抵消），**窗口内缺前一日 bar 抛 `InsufficientDepth`**。混起来会让 qfq 整段偏高且看不出来 |
| **§8 qfq 锚点（第 4 步）** | 只说 `qfq(t) = raw(t) × f(t)/f(T)`，没定 T | `factor.adjusted()` 默认锚**最后一根 bar**（输出确定性，可离线断言）；`Hub.adjusted()` 默认锚 **`self.target`**（和今天可比）。两者只在"最后一根 bar 之后又分红"时不同 |

`merge` 那条差异的原因值得记一笔（它不是口味问题，是 bug）：

> K 线是**滚动删除**的（只留 300 根）。如果 `merge` 对所有域都保留 `old.start`，那么 GC 删掉老 bar 之后，
> 下一次 `merge` 会用 `old.start` → `min(dates)` 这段"已经不存在了"的区间去重算缺口，
> 于是凭空造出一个假的头部缺口；这个假缺口还要按 1/6/24/72/168h 重试 6 次才变 `permanent`，
> 期间每次运行都 `blocking > 0` → 不命中 → 白打上游。第 2 步的测试（"start 取数据最早一天（不留旧边界）"）
> 是照着这个场景写的。

---

## 18. 未决项

| 项 | 现状 | 何时定 |
|---|---|---|
| 令牌桶 `RATE`（westock 15000 行/分钟） | 由实测下限 20–30k 的 60% 推得，**未做长跑校准** | 第 3 步实装后，用 300 只真跑一次，看冷却触发次数；>3 次就把 RATE 再降 20% |
| 冷却序列（30s 起、×2 到 300s、干净返回减半） | 实测只确认"6s 可恢复""30–45s 不一定够"，**减半规则是猜的** | 同上，长跑时观察是否抖动 |
| `tdx` 最小间隔 300ms | 保守取值，未实测；tdx 无批量，只能逐只 | tdx 若真无限频，可降到 100ms，全市场重建从 7–8 分钟压到 4 分钟 |
| `sync` vs `nosync` 的干净对照 | §18.4 那组被配额长尾污染，**没跑出干净对照** | 需要每档前静默 5 分钟交替；暂按"必须有跨进程共享"设计，量级上已够 |
| `HoleUnreachable` 的判定口径 | 现按"只含 permanent 洞且点数不足" | 第一次真遇到长期停牌股时校 |
| 周频 `valuation` 的组周规则 | 取该 ISO 周最后一个交易日 | 已与 quality 的 `_valuation()` 逐点比对过，无需再定 |
